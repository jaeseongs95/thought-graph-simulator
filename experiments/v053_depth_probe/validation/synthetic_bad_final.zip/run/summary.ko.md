# v053 D 정의 명시 대조

자료 무결성: True / 완료: True / 호출: 120/120
모델: test-only:4b-instruct / 출처: synthetic_fixture

유효 증명 생성은 방향 제어 성공과 다르다. 아래 대응쌍 성공을 함께 확인한다.

## 실제 깊이와 방향 이행

|문제/지시문/방향|배정|유효 증명|요청 깊이 일치|실제 깊이 분포|
|---|---:|---:|---:|---|
|K01/original/shallow|10|0|0|{'unmeasured': 10}|
|K01/original/deep|10|0|0|{'unmeasured': 10}|
|K01/original/neutral|10|0|해당 없음|{'unmeasured': 10}|
|K01/defined/shallow|10|0|0|{'unmeasured': 10}|
|K01/defined/deep|10|0|0|{'unmeasured': 10}|
|K01/defined/neutral|10|0|해당 없음|{'unmeasured': 10}|
|T02/original/shallow|10|0|0|{'unmeasured': 10}|
|T02/original/deep|10|0|0|{'unmeasured': 10}|
|T02/original/neutral|10|0|해당 없음|{'unmeasured': 10}|
|T02/defined/shallow|10|0|0|{'unmeasured': 10}|
|T02/defined/deep|10|0|0|{'unmeasured': 10}|
|T02/defined/neutral|10|0|해당 없음|{'unmeasured': 10}|

## 같은 seed의 shallow/deep 선택적 제어

|문제/지시문|배정 대응쌍|둘 다 유효|둘 다 요청 방향으로 변경|중립 대비 평균 차이|
|---|---:|---:|---:|---:|
|K01/original|10|0|0|0.00%p|
|K01/defined|10|0|0|0.00%p|
|T02/original|10|0|0|0.00%p|
|T02/defined|10|0|0|0.00%p|

## 판정 범위

original은 v052 D 단독의 요청 바이트를 유지했다. defined는 깊이 정의 문단 하나만 추가했다.
최소/최대 깊이 정답, 선택할 규칙, 예시 정답 그래프를 요청에 주지 않았다. 호스트가 경로를 골라주지 않는다.
모든 seed를 보고한다. 중립 재채점·대응쌍을 독립 문제로 더하지 않는다.
정의 명시 후 개선되어도 길이/주의 효과를 내부 기전에서 분리한 결과는 아니다.
A/M 또는 A×D×M 통합 성공으로 확대하지 않는다. 원래 v052 실패 기록은 그대로 보존한다.
계획 SHA-256: a2c304d7c565d99d57acb6ef8b91266dcfffcafea1746c845def32bcb399379d
마지막 event: 37b7c42138c2d65f56634135ee079b1efc31889fb6943d50f5437d1e7d46c514
동봉 원문과 계획의 일관성 검사이며 외부 실행 전자서명은 아니다.
