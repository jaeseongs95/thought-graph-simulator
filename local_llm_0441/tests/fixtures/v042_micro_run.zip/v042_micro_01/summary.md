# 로컬 LLM 분리 교정 결과

실험 식별 해시: `be3b83b6502dfdcd95489f3040a9344a00f049815e902da7616840e81b0679fb`

배정 8건 / 기록 8건 / 교정 과제 성공 6건

| 교정 과제 | 상태 |
| --- | --- |
| control_equal | accepted |
| criterion_goal_is_fact | invalid_task |
| criterion_neither | accepted |
| control_echo_2 | accepted |
| control_echo_1 | accepted |
| criterion_goal_not_fact | invalid_task |
| criterion_fact_not_goal | accepted |
| control_not_equal | accepted |

## 실행 완료와 성능 판정

실행 완료: True / 전 조건 통과 여부: False
전 조건 통과 여부가 False여도 일부 과제는 성공할 수 있다. 위 성공 건수와 구성요소별 결과를 함께 본다.
완료됐다는 이유로 모델의 실패를 성공으로 바꾸지 않는다.
프롬프트 프로필: `factorized-v4`

## 모델 실제값과 기대값

task_checks의 true/false는 일치 여부다. 모델이 출력한 판정값은 아래 실제값 열이다.
null은 해당 전제의 실패로 평가할 수 없음을 뜻한다.

| 과제 | 필드 | 실제값 | 기대값 | 일치 |
| --- | --- | --- | --- | --- |
| control_equal | equal | true | true | True |
| criterion_goal_is_fact | observed.probe_atom | "Cc" | "Cc" | True |
| criterion_goal_is_fact | observed.goal_atom | "Cc" | "Cc" | True |
| criterion_goal_is_fact | observed.facts | ["Ca", "Cc"] | ["Ca", "Cc"] | True |
| criterion_goal_is_fact | primitives.same_as_goal | true | true | True |
| criterion_goal_is_fact | primitives.in_facts | true | true | True |
| criterion_goal_is_fact | finding.answer_only_accepts | false | true | False |
| criterion_goal_is_fact | finding.proof_and_goal_accepts | false | true | False |
| criterion_goal_is_fact | finding.gap_detected | false | false | True |
| criterion_neither | observed.probe_atom | "Cz" | "Cz" | True |
| criterion_neither | observed.goal_atom | "Cc" | "Cc" | True |
| criterion_neither | observed.facts | ["Ca"] | ["Ca"] | True |
| criterion_neither | primitives.same_as_goal | false | false | True |
| criterion_neither | primitives.in_facts | false | false | True |
| criterion_neither | finding.answer_only_accepts | false | false | True |
| criterion_neither | finding.proof_and_goal_accepts | false | false | True |
| criterion_neither | finding.gap_detected | false | false | True |
| control_echo_2 | token | "VT_83R" | "VT_83R" | True |
| control_echo_2 | flag | true | true | True |
| control_echo_1 | token | "NX_47Q" | "NX_47Q" | True |
| control_echo_1 | flag | false | false | True |
| criterion_goal_not_fact | observed.probe_atom | "Cc" | "Cc" | True |
| criterion_goal_not_fact | observed.goal_atom | "Cc" | "Cc" | True |
| criterion_goal_not_fact | observed.facts | ["Ca"] | ["Ca"] | True |
| criterion_goal_not_fact | primitives.same_as_goal | true | true | True |
| criterion_goal_not_fact | primitives.in_facts | false | false | True |
| criterion_goal_not_fact | finding.answer_only_accepts | false | true | False |
| criterion_goal_not_fact | finding.proof_and_goal_accepts | false | false | True |
| criterion_goal_not_fact | finding.gap_detected | false | true | False |
| criterion_fact_not_goal | observed.probe_atom | "Ca" | "Ca" | True |
| criterion_fact_not_goal | observed.goal_atom | "Cc" | "Cc" | True |
| criterion_fact_not_goal | observed.facts | ["Ca"] | ["Ca"] | True |
| criterion_fact_not_goal | primitives.same_as_goal | false | false | True |
| criterion_fact_not_goal | primitives.in_facts | true | true | True |
| criterion_fact_not_goal | finding.answer_only_accepts | false | false | True |
| criterion_fact_not_goal | finding.proof_and_goal_accepts | false | false | True |
| criterion_fact_not_goal | finding.gap_detected | false | false | True |
| control_not_equal | equal | false | false | True |

## 구성요소별 결과

| 과제 | 성공 | 기록 | 배정 |
| --- | ---: | ---: | ---: |
| literal_equality | 2 | 2 | 2 |
| criterion_witness | 2 | 4 | 4 |
| input_echo | 2 | 2 | 2 |

기준 판정 정답 패턴과 실제 응답 패턴은 `component_diagnostics.json`에서 분리한다.
동일한 고정 증명의 전체 도식/최종 도식 단독 결과도 짝지어 보존한다. 이는 진단 비교이지 본 실험의 성공 기준 완화가 아니다.

## 실행 모드

체크포인트: instruct-2507; 모드: non-thinking; think 필드: omitted.
메타데이터 검사와 실제 응답 채널 검사를 분리했다. 이 표는 모델 성능이 개선됐다는 뜻이 아니다.
예산: {"temperature": 0.7, "top_p": 0.8, "top_k": 20, "min_p": 0.0, "repeat_penalty": 1.0, "num_ctx": 8192, "num_predict": 4096, "num_thread": 6, "num_batch": 256}

## 실패 구분

분리 과제는 위 실제값/기대값과 task_comparisons.json을 기준으로 본다. 통합 증명 전체가 없는 과제의 층위 집계를 0건 성공/실패로 해석하지 않는다.

```json
{
  "applicable": false,
  "note": "통합 증명용 오류 집계를 분리 과제에 0건으로 적용하지 않는다. task_comparisons와 details를 확인한다."
}
```

## 비용

```json
{
  "known_prompt_eval_count_sum": 2429,
  "unknown_prompt_eval_count_cases": 0,
  "known_prompt_eval_cached_count_sum": 1582,
  "unknown_prompt_eval_cached_count_cases": 0,
  "known_eval_count_sum": 434,
  "unknown_eval_count_cases": 0,
  "known_api_wall_seconds_sum": 8.954677700000502,
  "note": "실패 호출도 포함. 미수신 비용은 null/unknown이며 0으로 추정하지 않음. 비용 절감 결론이 아님.",
  "token_scope": "eval_count는 API 생성 토큰 합계. thinking/최종 토큰을 분리해 추정하지 않는다."
}
```

## 해석 범위

분리 진단 8회 수행 여부. 고정 입력에 대한 구성요소 작업이며 통합 A/D/M 결과에 합산하지 않음.

반복 시드는 같은 문제의 반복 측정이다. 독립된 문제 수나 새 표본으로 부풀리지 않는다. 토큰 수·시간은 서로 다른 출력 작업량과 캐시·최초 로딩을 포함하므로 곧바로 효율 향상으로 읽지 않는다.

## 형식·내용 진단

`task_evidence.json`은 채점과 별도인 읽기 전용 증거다. 오류 응답도 정규화하거나 보충하지 않는다.
같은 도식 범위의 여러 조건은 모두 보존한다. 임의로 마지막 조건을 대표 결과로 쓰지 않는다.

## 최소 진단의 다음 분기

계약: `micro-v042` (기본 프롬프트 프로필과 별도)
입력 대조와 도움을 제공한 연결 과제를 포함하므로 총 성공률은 일반 추론/ADM 성능이 아니다.
진단 분기: `control_passed_literal_decision_unreliable_in_this_condition`. 내부 원인 확정이나 다수결이 아니다.
원문 판정과 출력된 중간값의 오류 위치는 `micro_probe.json`에서 확인한다.
