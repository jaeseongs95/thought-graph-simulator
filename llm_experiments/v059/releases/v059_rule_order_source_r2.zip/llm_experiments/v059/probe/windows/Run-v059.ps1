param(
    [string]$RunName = ('v059_rules_' + (Get-Date -Format 'yyyyMMdd_HHmmss')),
    [string]$BaselineBundle = '',
    [switch]$CheckOnly,
    [switch]$NoPause
)
$ErrorActionPreference = 'Stop'
$probeRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$versionRoot = [IO.Path]::GetFullPath((Join-Path $probeRoot '..'))
if ($RunName -notmatch '^v059_[A-Za-z0-9_-]+$') { throw 'RunName must start with v059_ and use safe letters/digits.' }
if (-not $BaselineBundle) {
    $BaselineBundle = [IO.Path]::GetFullPath((Join-Path $probeRoot '../../v058/results_llm/v058_order_02_evidence.zip'))
}
$planPath = Join-Path $versionRoot ('experiments/' + $RunName + '.plan.json')
$runPath = Join-Path $versionRoot ('results_llm/' + $RunName)
$bundlePath = Join-Path $versionRoot ('results_llm/' + $RunName + '_evidence.zip')
$verifyPath = Join-Path $versionRoot ('results_llm/' + $RunName + '_independent.json')
$priorPythonEncoding = $env:PYTHONIOENCODING
$env:PYTHONIOENCODING = 'utf-8'
function Invoke-PythonChecked {
    param([string[]]$Arguments)
    & python -B @Arguments
    if ($LASTEXITCODE -ne 0) { throw ('Python failed with exit ' + $LASTEXITCODE + '. No retry performed.') }
}
$resultCode = 0
Push-Location $probeRoot
try {
    Invoke-PythonChecked -Arguments @('-m', 'rule_order_v059', 'selftest')
    Invoke-PythonChecked -Arguments @('-m', 'rule_order_v059', 'prepare', '--baseline-bundle', $BaselineBundle, '--out', $planPath)
    Invoke-PythonChecked -Arguments @('-m', 'rule_order_v059', 'show', '--plan', $planPath)
    if (-not $CheckOnly) {
        Write-Host 'Starting 40 new Ollama calls. Existing runs are preserved; failed calls are not retried.'
        Invoke-PythonChecked -Arguments @('-m', 'rule_order_v059', 'run', '--plan', $planPath, '--out', $runPath)
        Invoke-PythonChecked -Arguments @('-m', 'rule_order_v059', 'bundle', '--plan', $planPath, '--run', $runPath, '--out', $bundlePath)
        Invoke-PythonChecked -Arguments @('tools/verify_v059.py', $bundlePath, '--out', $verifyPath)
    }
} catch {
    Write-Host $_ -ForegroundColor Red
    $resultCode = 1
} finally {
    Pop-Location
    $env:PYTHONIOENCODING = $priorPythonEncoding
    if (-not $NoPause) { Read-Host 'Press Enter to close' | Out-Null }
}
exit $resultCode
