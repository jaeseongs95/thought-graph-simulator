@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-v060.ps1" %*
