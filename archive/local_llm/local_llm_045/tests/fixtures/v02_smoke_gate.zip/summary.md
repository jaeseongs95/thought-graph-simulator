# 로컬 LLM 고정 목표 A/D/M 실험 결과

실험 식별 해시: `175dbe3f6ebb703c9445faddc032ba9dfd0b2febbb8c5082c613233f2ff7f6bd`

배정 6건 / 기록 6건 / 미기록 0건
유효한 고정 목표 증명 기록: 5 / 6
지정 역할 준수: 1 / 5
축별 대조: 0 / 4

실패·중단·미실행 조건을 분모에서 제외하지 않았다. 중립 조건은 역할 준수율에서만 제외한다.

| 역할 | 배정 | 기록 | 유효 | 역할 준수 |
| --- | ---: | ---: | ---: | ---: |
| schema_shallow_M0 | 1 | 1 | 1 | 0 |
| instance_deep_M0 | 1 | 1 | 1 | 1 |
| instance_shallow_M0 | 1 | 1 | 1 | 0 |
| instance_shallow_M2 | 1 | 1 | 1 | 0 |
| instance_shallow_M1 | 1 | 1 | 1 | 0 |
| neutral | 1 | 1 | 0 | 해당 없음 |

## 실패 구분

`metrics.csv`의 proof_valid / representation_valid / review_valid를 함께 본다. 증명 자체가 무효라 표현/검토를 검사할 수 없으면 해당 값은 null이다. 각 층위 진단은 원문을 고쳐서 통과시킨 결과가 아니다. 최종 유효성은 원본 전체 검사로 결정한다.

```json
{
  "final_reference_missing": 0,
  "all_local_steps_valid": 6,
  "missing_parent_reference": 0,
  "empty_binding": 0,
  "representation_assessable": 6,
  "review_assessable": 6
}
```

## 비용

```json
{
  "known_prompt_eval_count_sum": 14358,
  "unknown_prompt_eval_count_cases": 0,
  "known_prompt_eval_cached_count_sum": 8542,
  "unknown_prompt_eval_cached_count_cases": 0,
  "known_eval_count_sum": 1956,
  "unknown_eval_count_cases": 0,
  "known_api_wall_seconds_sum": 29.449609000002965,
  "note": "실패 호출도 포함. 미수신 비용은 null/unknown이며 0으로 추정하지 않음. 비용 절감 결론이 아님."
}
```

## 해석 범위

고정 목표의 형식 기록에서 지시한 A/D/M 조작을 따르는지 관측. 내부 사고 좌표, 차원 독립성의 일반 증명, H7b 라우터 검증이 아님.

반복 시드는 같은 문제의 반복 측정이다. 독립된 문제 수나 새 표본으로 부풀리지 않는다. 토큰 수·시간은 서로 다른 출력 작업량과 캐시·최초 로딩을 포함하므로 곧바로 효율 향상으로 읽지 않는다.
