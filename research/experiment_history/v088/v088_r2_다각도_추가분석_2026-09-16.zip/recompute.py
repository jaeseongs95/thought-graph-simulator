"""v088 r2의 A/B 원응답 추가 탐색 분석. 모델 호출·응답 보정 없음.
실행: python recompute.py --evidence <원본 evidence.zip> --out <출력 폴더>
기존 production/independent 검산기를 import하지 않는다.
"""
from pathlib import Path
from collections import Counter, defaultdict
import json,zipfile,hashlib,csv,argparse

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--evidence',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 z=zipfile.ZipFile(a.evidence);load=lambda n:json.loads(z.read(n));plan=load('plan.json');summary=load('summary.json');sm={r['trial_id']:r for r in summary['rows']};slots=defaultdict(list)
 for s in plan['slots']:slots[s['trial_id']].append(s)
 outcomes=[];rules=[];cost=defaultdict(Counter)
 def hist(d):
  ns=[]
  for h in d['history']:
   o=json.loads(h['content']);ns.extend(o['nodes'] if 'nodes' in o else [o['node']])
  return ns
 def check(h,n,r):
  ix=defaultdict(list)
  for v in h:ix[v['id']].append(v)
  e=[]
  if n['id'] in ix:e.append('duplicate_node_id')
  if n['rule']!=r['id']:e.append('wrong_rule')
  if n['atom']!=r['conclusion']:e.append('wrong_atom')
  if len(set(n['parents']))!=len(n['parents']):e.append('duplicate_parent')
  miss=[x for x in n['parents'] if x not in ix]
  if miss:e.append('missing_parent')
  if any(len(ix[x])>1 for x in n['parents']):e.append('ambiguous_parent_id')
  if all(len(ix[x])==1 for x in n['parents']) and Counter(ix[x][0]['atom'] for x in n['parents'])!=Counter(r['premises']):e.append('premise_counter_mismatch')
  return e,miss
 for t in plan['trials']:
  phase=t['phase'];tid=t['id'];arm=t['generator_arm']
  if phase not in ['rename_probe','continuation']:continue
  valid=True;first=None;before=None;initial=None
  for s in slots[tid]:
   sid=s['id'];rec=load('records/'+sid+'.json');qb=z.read('wire/'+sid+'/request.wire.json');rb=z.read('wire/'+sid+'/response.raw.json')
   assert rec['kind']=='call' and rec['http_status']==200 and rec['error'] is None
   assert hashlib.sha256(qb).hexdigest()==rec['request_sha256'] and hashlib.sha256(rb).hexdigest()==rec['response_sha256']
   q=json.loads(qb);r=json.loads(rb);assert r['done'] and r['done_reason']=='stop';obj=json.loads(r['message']['content']);d=json.loads(q['messages'][0]['content'].split('\n\ninput: ',1)[1]);h=hist(d)
   c=cost[phase+'/'+arm];c['calls']+=1
   for k in ['prompt_eval_count','eval_count','total_duration']:c[k]+=r[k]
   if phase=='continuation':
    if before is None:initial=h.copy();before=h.copy()
    assert h==before,('history continuity',sid)
   if s['stage']=='rule':
    n=obj['node'];rule=d['operation']['requested_rule'];e,miss=check(h,n,rule)
    if phase=='continuation':assert n['id']==d['allocated_node_id'];before.append(n)
    rules.append(dict(trial_id=tid,phase=phase,arm=arm,problem_id=t['problem_id'],seed=t['seed'],condition=t['condition'],position=s['rule_position']+1,arity=len(rule['premises']),rule_id=rule['id'],prefix_valid=valid,valid=not e,errors=e,missing_ids=miss))
    if e and first is None:first=e[0]
    valid=valid and not e
   else:
    fid=obj['final_node_id'];ix={n['id']:n for n in before};assert fid in ix and ix[fid]['atom']==d['problem']['goal']
    if valid:
     depth={};anc={}
     for n in before:
      if n['rule'] is None:depth[n['id']]=0;anc[n['id']]=set()
      else:depth[n['id']]=1+max(depth[x] for x in n['parents']);anc[n['id']]=set(n['parents']).union(*(anc[x] for x in n['parents']))
     assert depth[fid]==sm[tid]['target_D']
     assert all(n['rule'] is None or n['id'] in anc[fid]|{fid} for n in before)
  key='probe_success' if phase=='rename_probe' else 'continuation_success';assert valid==sm[tid][key],tid
  row=dict(trial_id=tid,problem_id=t['problem_id'],seed=t['seed'],condition=t['condition'],arm=arm,phase=phase,success=valid,first_failure=first or 'success')
  if initial is not None:
   row['initial_nodes']=initial
   row['initial_style']='atom_equal' if all(n['id']==n['atom'] for n in initial) else ('n001_series' if all(n['id'].startswith('n00') for n in initial) else 'node_atom')
  outcomes.append(row)
 B=[r for r in outcomes if r['phase']=='continuation'];bm={(r['problem_id'],r['seed'],r['condition'],r['arm']):r for r in B};strat={};trans={}
 for fam in ['short','long']:
  cc=Counter()
  for typ in ['atom_equal','n001_series','node_atom']:
   rr=[r for r in B if r['arm']==fam+'_mixed' and r['initial_style']==typ];uu=[bm[(r['problem_id'],r['seed'],r['condition'],fam+'_uniform')] for r in rr]
   strat[fam+'/'+typ]=dict(n=len(rr),mixed_success=sum(r['success'] for r in rr),mixed_first_missing=sum(r['first_failure']=='missing_parent' for r in rr),uniform_success=sum(r['success'] for r in uu),uniform_first_missing=sum(r['first_failure']=='missing_parent' for r in uu))
   for r,u in zip(rr,uu):cc[r['first_failure']+' -> '+u['first_failure']]+=1
  trans[fam]=dict(cc)
 pairs=[];dist={}
 for arm in ['short_mixed','short_uniform','long_mixed','long_uniform']:
  groups=defaultdict(list)
  for r in B:
   if r['arm']==arm:groups[(r['problem_id'],r['seed'])].append(r)
  cc=Counter(sum(r['success'] for r in g) for g in groups.values());dist[arm]=dict(neither=cc[0],one_only=cc[1],both=cc[2])
  for (pid,seed),g in groups.items():pairs.append(dict(problem_id=pid,seed=seed,arm=arm,both=all(r['success'] for r in g)))
 effects={}
 for pid in sorted({r['problem_id'] for r in B}):
  u=[r['both'] for r in pairs if r['problem_id']==pid and r['arm']=='long_uniform'];m=[r['both'] for r in pairs if r['problem_id']==pid and r['arm']=='long_mixed'];effects[pid]=sum(u)/len(u)-sum(m)/len(m)
 arity={}
 for arm in ['observed','atom_alias','short','legacy_long']:
  arity[arm]={}
  for n in [1,2,3]:
   rr=[r for r in rules if r['phase']=='rename_probe' and r['arm']==arm and r['arity']==n];arity[arm][str(n)]=dict(n=len(rr),success=sum(r['valid'] for r in rr))
 hazard={}
 for arm in dist:
  hazard[arm]=[]
  for pos in range(1,6):
   rr=[r for r in rules if r['phase']=='continuation' and r['arm']==arm and r['position']==pos];risk=[r for r in rr if r['prefix_valid']];hazard[arm].append(dict(step=pos,scheduled=len(rr),valid_prefix=len(risk),first_failures=sum(not r['valid'] for r in risk)))
 overlap=Counter((r['success'],bm[(r['problem_id'],r['seed'],r['condition'],'long_uniform')]['success']) for r in B if r['arm']=='short_uniform')
 result=dict(scope='posthoc exploratory; no new samples; not a replacement preregistered endpoint; no population p-values',evidence_sha256=hashlib.sha256(a.evidence.read_bytes()).hexdigest(),A_raw_trials=sum(r['phase']=='rename_probe' for r in outcomes),B_raw_graphs=len(B),AB_rule_responses=len(rules),AB_summary_disagreements=0,initial_style_stratification=strat,paired_first_failure_transitions=trans,pair_distribution=dist,uniform_outcome_overlap={str(k):v for k,v in overlap.items()},primary_structure_effects=effects,leave_one_out_primary={p:sum(v for k,v in effects.items() if k!=p)/7 for p in effects},A_arity=arity,B_first_failure_hazard=hazard,response_reported_cost=dict(cost),new_model_calls=0)
 for name,obj in [('multiview_metrics.json',result),('raw_AB_trials.json',outcomes),('raw_AB_rules.json',rules),('B_pairs.json',pairs)]:
  (a.out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 with (a.out/'B_initial_style.csv').open('w',encoding='utf-8-sig',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=['trial_id','problem_id','seed','condition','arm','initial_style','success','first_failure']);wr.writeheader()
  for r in B:wr.writerow({k:r[k] for k in wr.fieldnames})
 print(json.dumps({k:result[k] for k in ['evidence_sha256','A_raw_trials','B_raw_graphs','AB_rule_responses','AB_summary_disagreements','initial_style_stratification']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
