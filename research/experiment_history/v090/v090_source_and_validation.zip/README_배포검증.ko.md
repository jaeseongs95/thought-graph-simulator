# v090 배포 자료

실행 파일은 Run-v090-Auto.ps1 하나다. ZIP 안의 소스를 사용자 저장소에 수동 덮어쓰기하지 않는다. 실험 배정·지원 계약·실행 명령은 v090_실험설계_검증결과.md와 PREREGISTRATION_v090.ko.md에 있다.

VALIDATION_RESULT_v090.json은 이번 최종 설치본에서 수행한 검증 기록이다. validation/synthetic_* 및 v090_full_synthetic_independent.json은 모델을 호출하지 않은 합성 검사이며 연구 결과가 아니다.

SHA256SUMS.json은 배포 묶음 안의 파일 해시다. 해당 파일 자체와 최상위 전체 배포 ZIP은 자기참조를 피하기 위해 목록에서 제외한다. verify_release_artifacts.py를 실행하면 배포 파일, source manifest, PS1 내장 ZIP의 일치를 확인한다. 이 검사는 모델을 호출하거나 파일을 변경하지 않는다.

```text
python -X utf8 -B verify_release_artifacts.py
```
