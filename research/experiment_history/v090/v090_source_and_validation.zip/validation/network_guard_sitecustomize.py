import socket
_original = socket.socket.connect
def _guard(self, address):
    if isinstance(address, tuple) and len(address) >= 2:
        host, port = address[0], address[1]
        if host not in ('127.0.0.1', 'localhost', '::1') or port == 11434:
            raise AssertionError('Validation attempted a model/external network connection: '+repr(address))
    return _original(self, address)
socket.socket.connect = _guard
