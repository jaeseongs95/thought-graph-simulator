"""배포 묶음 해시와 PS1 내장 소스 검증. 읽기 전용이며 네트워크를 사용하지 않는다."""
from pathlib import Path
import base64, hashlib, json, re, zipfile

def main():
    root=Path(__file__).resolve().parent
    digest=lambda b:hashlib.sha256(b).hexdigest()
    manifest=json.loads((root/'SHA256SUMS.json').read_text(encoding='utf-8'))
    for name,expected in manifest['file_hashes'].items():
        path=(root/name).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError('파일/경로 오류: '+name)
        if digest(path.read_bytes())!=expected:
            raise ValueError('배포 해시 불일치: '+name)
    source=(root/'v090_fresh_semantic_id_source.zip').read_bytes()
    text=(root/'Run-v090-Auto.ps1').read_text(encoding='utf-8-sig')
    payload=re.search(r"\$EmbeddedSource=@'\r?\n(.*?)\r?\n'@",text,re.S)
    expected=re.search(r"\$ExpectedSha256='([0-9a-f]{64})'",text)
    if not payload or not expected or base64.b64decode(payload.group(1))!=source or digest(source)!=expected.group(1):
        raise ValueError('내장 ZIP 불일치')
    with zipfile.ZipFile(root/'v090_fresh_semantic_id_source.zip') as z:
        m=json.loads(z.read('RELEASE_MANIFEST.json'))
        if set(z.namelist())!=set(m['file_hashes'])|{'RELEASE_MANIFEST.json'}:
            raise ValueError('소스 파일 집합 불일치')
        for name,expected_hash in m['file_hashes'].items():
            if digest(z.read(name))!=expected_hash:
                raise ValueError('소스 해시 불일치: '+name)
    print(json.dumps({'verified':True,'distribution_files':len(manifest['file_hashes']),
                      'source_files':len(m['file_hashes']),'embedded_source_identical':True,
                      'actual_model_calls':0},ensure_ascii=False,indent=2))
    return 0
if __name__=='__main__':
    raise SystemExit(main())
