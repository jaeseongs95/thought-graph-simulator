"""v089 무보정 재채점 결과의 별도 집계와 원문 조건 불변성 검사.
생산/제공된 독립 집계 모듈은 import하지 않는다. 모델 호출을 하지 않는다.
"""
from pathlib import Path
from collections import Counter, defaultdict
from copy import deepcopy
import argparse, json, hashlib, zipfile, csv

pa=argparse.ArgumentParser(description=__doc__)
pa.add_argument('--evidence-dir',type=Path,required=True)
pa.add_argument('--raw-audit-dir',type=Path,required=True)
pa.add_argument('--out',type=Path,required=True)
a=pa.parse_args();R=a.evidence_dir;V=a.raw_audit_dir;O=a.out;O.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(n,d): (O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def wire(d):return json.dumps(d,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def sha(b):return hashlib.sha256(b).hexdigest()
p=read(R/'plan.json');s=p['protocol'];sm=read(R/'summary.json');dg=read(R/'diagnostics.json')
rows=read(V/'raw_audit_trials.json');steps=read(V/'raw_steps.json');stepmap={t['slot_id']:t for t in steps}
trials={t['id']:t for t in p['trials']};slots=defaultdict(list)
for slot in p['slots']:slots[slot['trial_id']].append(slot)
styles=s['initial_id_styles'];groups=defaultdict(list)
for r in rows:groups[(r['phase'],r['arm'])].append(r)
matrix={};pairrows=[];structure=[];summary_agreements=0
for (phase,arm),rs in groups.items():
 prs=defaultdict(list)
 for r in rs:prs[r['pair_id']].append(r)
 pr=[]
 for pair,items in prs.items():
  assert len(items)==2 and {r['condition'] for r in items}=={'shallow','deep'}
  k=sum(r['success'] for r in items)
  q=dict(phase=phase,arm=arm,pair_id=pair,base_pair_id=items[0]['base_pair_id'],problem_id=items[0]['problem_id'],seed=items[0]['seed'],success=k==2,successful_directions=k)
  pr.append(q);pairrows.append(q)
 byp={pid:dict(n=sum(r['problem_id']==pid for r in rs),success=sum(r['success'] for r in rs if r['problem_id']==pid),pairs=sum(r['problem_id']==pid for r in pr),pair_success=sum(r['success'] for r in pr if r['problem_id']==pid)) for pid in sorted({r['problem_id'] for r in rs})}
 first=Counter('success' if r['success'] else '|'.join(r['first_error'] or ['other']) for r in rs)
 rec=dict(n=len(rs),success=sum(r['success'] for r in rs),pairs=len(pr),pair_success=sum(r['success'] for r in pr),pair_distribution={str(k):sum(r['successful_directions']==k for r in pr) for k in (0,1,2)},first_error_classes=dict(first),per_structure=byp)
 matrix[phase+'/'+arm]=rec
 source=sm['groups'][phase][arm]
 assert rec['success']==source['outcome']['success'] and rec['pair_success']==source['bidirectional']['success']
 for pid,g in byp.items():
  assert g['success']==source['per_structure'][pid]['outcome']['success'] and g['pair_success']==source['per_structure'][pid]['bidirectional']['success']
  structure.append(dict(phase=phase,arm=arm,problem_id=pid,**g))
 summary_agreements+=1

def comparison(left,right):
 aa={r['unit_id']:r for r in groups['continuation',left]};bb={r['unit_id']:r for r in groups['continuation',right]};assert aa.keys()==bb.keys()
 paired=Counter();trans=Counter()
 for k in aa:
  l,r=aa[k],bb[k];paired['both_success' if l['success'] and r['success'] else 'loss' if l['success'] else 'gain' if r['success'] else 'both_failure']+=1
  trans[('success' if l['success'] else '|'.join(l['first_error'] or ['other']))+' -> '+('success' if r['success'] else '|'.join(r['first_error'] or ['other']))]+=1
 lmat=matrix['continuation/'+left];rmat=matrix['continuation/'+right]
 ds={pid:rmat['per_structure'][pid]['pair_success']/rmat['per_structure'][pid]['pairs']-lmat['per_structure'][pid]['pair_success']/lmat['per_structure'][pid]['pairs'] for pid in lmat['per_structure']}
 return dict(left=left,right=right,matched_outcomes=dict(paired),first_error_transitions=dict(trans),per_structure=ds,mean_delta=sum(ds.values())/len(ds))
contrasts={l+' -> '+r:comparison(l,r) for l,r in s['primary_components']+s['secondary_comparisons']}
primary_by={pid:sum(contrasts[l+' -> '+r]['per_structure'][pid] for l,r in s['primary_components'])/len(s['primary_components']) for pid in matrix['continuation/'+s['continuation_arms'][0]]['per_structure']}
primary=sum(primary_by.values())/len(primary_by)
assert primary==sm['primary']['mean_delta']
assert all(x['delta']==primary_by[x['problem_id']] for x in sm['primary']['per_structure'])
for declared in sm['secondary']:
 assert contrasts[declared['left']+' -> '+declared['right']]['mean_delta']==declared['mean_delta']
loo={pid:sum(v for q,v in primary_by.items() if pid!=q)/(len(primary_by)-1) for pid in primary_by}
# Four-display baseline bundles, independently assembled.
robust=defaultdict(list)
for r in groups['end_to_end','baseline']:robust[r['problem_id'],r['seed']].append(r)
assert all(len(v)==8 for v in robust.values())
robust_result=dict(n=len(robust),success=sum(all(x['success'] for x in rs) for rs in robust.values()))
# Validate raw history continuity and independent expected names.
anchors={x['id']:x for x in read(R/'source/data/anchors.json')};requests={};payloads={};raws={};input_strings={}
for t in p['trials']:
 for o in slots[t['id']]:
  qpath=R/'wire'/o['id']/'request.wire.json'
  if not qpath.exists():continue
  q=read(qpath);qheader,d=q['messages'][0]['content'].split('\n\ninput: ',1)
  requests[o['id']]=q;payloads[o['id']]=json.loads(d);input_strings[o['id']]=qheader
  raws[o['id']]=read(R/'wire'/o['id']/'response.raw.json')

def named(atom,i,sty):
 return atom if sty=='atom_alias' else 'node_'+atom if sty=='atom_tagged' else ('n' if sty=='short' else 'v087_node_')+f'{i:04d}'
history_checks=0;allocation_checks=0;initial_checks=0;semantically_invariant_units=defaultdict(list);sequences=defaultdict(list)
for t in p['trials']:
 own=[o for o in slots[t['id']] if o['stage'] in ('facts','rule','final') and o['id'] in payloads]
 if t['phase']=='continuation':
  first=own[0]['id'];a0=json.loads(anchors[t['anchor_id']]['request_body']['messages'][0]['content'].split('\n\ninput: ',1)[1]);h=deepcopy(a0['history'])
  n=json.loads(h[0]['content'])
  for i,nd in enumerate(n['nodes'],1):nd['id']=named(nd['atom'],i,t['initial_id_style'])
  h[0]['content']=wire(n);assert h==payloads[first]['history'];initial_checks+=1
  rulemap={x['id']:x for x in a0['problem']['rules']}
  expected=[named(rulemap[rid]['conclusion'],i,t['output_id_style']) for i,rid in enumerate(t['route_rule_ids'],len(n['nodes'])+1)]
  initial_ids={named(nd['atom'],i,sty) for sty in styles for i,nd in enumerate(n['nodes'],1)}
  assert not(initial_ids&set(expected)) and len(set(expected))==len(expected)
  seq=[payloads[o['id']]['allocated_node_id'] for o in own if o['stage']=='rule']
  assert seq==expected;allocation_checks+=len(seq);sequences[t['unit_id'],t['output_id_style']].append(seq)
  q=deepcopy(requests[first]);d=deepcopy(payloads[first]);h0=json.loads(d['history'][0]['content'])
  for i,nd in enumerate(h0['nodes']):nd['id']='initial_'+str(i)
  d['history'][0]['content']=wire(h0);q['messages'][0]['content']=input_strings[first]+'\n\ninput: '+wire(d)
  semantically_invariant_units[t['unit_id'],t['output_id_style']].append(q)
 else:h=[]
 for o in own:
  sid=o['id'];assert payloads[sid]['history']==h,(sid,'history was changed')
  history_checks+=1
  if o['stage']!='final':h.append(dict(source_slot_id=o['logical_id'],content=raws[sid]['message']['content']))
assert all(len(xs)==4 and all(x==xs[0] for x in xs) for xs in semantically_invariant_units.values())
assert all(len(xs)==4 and all(x==xs[0] for x in xs) for xs in sequences.values())
# Rule risk sets, counting each graph's first failure only once.
risks=defaultdict(Counter)
for t in p['trials']:
 if t['phase']!='continuation':continue
 good=True
 for o in slots[t['id']]:
  if o['stage'] not in ('rule','final'):continue
  step=stepmap[o['id']]
  if o['stage']=='rule' and good:
   r=risks[t['generator_arm'],o['rule_position']];r['eligible']+=1;r['success' if step['valid'] and step['support_ok'] else 'failure']+=1
  good=good and step['valid'] and step['support_ok']
for d in dg['step_risk_sets']:
 rc=risks[d['arm'],d['rule_position']]
 assert rc['eligible']==d['eligible'] and rc['success']==d['success'] and rc['failure']==d['failure']
# Precise error/reference descriptions; prior-invalid and first-error rows kept separate.
refs={};diagonal_failures=[]
for arm in s['continuation_arms']:
 rr=[x for x in steps if x['phase']=='continuation' and x['arm']==arm and x['stage']=='rule']
 firstids={r['first_error_slot'] for r in groups['continuation',arm] if not r['success']}
 refs[arm]=dict(rule_count=len(rr),missing_parent_rules=sum('missing_parent' in x['errors'] for x in rr),missing_parent_all_are_atoms=sum(x.get('missing_ids_all_are_existing_atoms',False) for x in rr),first_missing_parent=sum('missing_parent' in x['errors'] for x in rr if x['slot_id'] in firstids),first_premise_error=sum('premise_counter_mismatch' in x['errors'] for x in rr if x['slot_id'] in firstids),first_rule_valid=sum(x['valid'] for x in rr if x['position']==0))
 if arm.split('__')[0]==arm.split('__')[1]:
  for r in groups['continuation',arm]:
   if not r['success']:diagonal_failures.append(dict(trial=r,step=stepmap[r['first_error_slot']]))
# Exact baseline comparisons with preserved v088, without attributing changes to runtime.
with zipfile.ZipFile(R/'baseline/v088_evidence.zip') as z:
 old=json.loads(z.read('summary.json'));oldrows={r['trial_id']:r for r in old['rows'] if r['phase']=='end_to_end' and r['generator_arm']=='baseline'}
 match=Counter();request_stages=defaultdict(Counter);different_content_examples=[]
 for r in groups['end_to_end','baseline']:
  b=oldrows[r['trial_id']];l=b['end_to_end_success'];now=r['success'];match['both_success' if l and now else 'old_only' if l else 'new_only' if now else 'both_failed']+=1
  for o in slots[r['trial_id']]:
   sid=o['id'];name='wire/'+sid+'/request.wire.json'
   if sid not in requests:continue
   oldq=z.read(name);newq=(R/name).read_bytes();c=request_stages[o['stage']];c['observed']+=1
   if oldq==newq:
    c['identical_request']+=1
    oldr=json.loads(z.read('wire/'+sid+'/response.raw.json'))
    if oldr['message']['content']==raws[sid]['message']['content']:c['same_reply_content']+=1
    elif len(different_content_examples)<6:different_content_examples.append(sid)
 # Export prior summary as original source, not new evidence.
 (O/'v088_original_summary.ko.md').write_bytes(z.read('summary.ko.md'))
# Pair overlaps of semantic-ID diagonal arms. This is descriptive, not a combined policy outcome.
semantic_overlap=comparison('atom_alias__atom_alias','atom_tagged__atom_tagged')
# Grouped scalar exports.
output=dict(contract='v089-additional-raw-analysis-20260916',matrices=matrix,primary=primary,primary_by_structure=primary_by,leave_one_structure_out=loo,contrasts=contrasts,baseline_robust=robust_result,reference_errors=refs,semantic_diagonal_overlap=semantic_overlap,baseline_vs_v088=dict(matched=match,request_stages=request_stages,changed_content_under_identical_request_examples=different_content_examples),field_invariance=dict(initial_fact_renamings_checked=initial_checks,allocated_ids_checked=allocation_checks,new_id_sequences_equal_across_initials=len(sequences),first_request_equivalent_after_initial_ID_normalization=len(semantically_invariant_units),unchanged_raw_histories_checked=history_checks),independent_aggregation=dict(group_agreements=summary_agreements,pairs_recomputed=len(pairrows),whole_structure_bundles=len(robust)),new_inference_calls=0)
save('additional_metrics.json',output);save('pair_rows.json',pairrows);save('diagonal_first_failures.json',diagonal_failures)
save('risk_sets.json',[dict(arm=k[0],rule_position=k[1],**v) for k,v in sorted(risks.items())])
for name,data in [('structure_results.csv',structure),('pair_rows.csv',pairrows)]:
 keys=list(data[0]);f=(O/name).open('w',encoding='utf-8-sig',newline='');w=csv.DictWriter(f,keys);w.writeheader();w.writerows(data);f.close()
print(json.dumps({k:output[k] for k in ('primary','primary_by_structure','leave_one_structure_out','baseline_robust','field_invariance','independent_aggregation','baseline_vs_v088')},ensure_ascii=False,indent=2))
