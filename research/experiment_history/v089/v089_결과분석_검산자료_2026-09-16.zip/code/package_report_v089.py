"""실제 완료된 v089 검산 자료로 한국어 분석 보고서를 작성한다. 모델 호출 없음."""
from pathlib import Path
import json,hashlib,shutil,zipfile
from datetime import datetime
R=Path('/mnt/data/v089_work');O=Path('/mnt/data/v089_analysis_2026-09-16');V=O/'validation'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(b):return hashlib.sha256(b).hexdigest()
p=read(R/'plan.json');s=p['protocol'];raw=read(V/'derived_metrics.json');extra=read(V/'additional_metrics.json');audit=read(V/'raw_audit_result.json');summary=read(R/'summary.json')
rows=read(V/'raw_audit_trials.json');steps=read(V/'raw_steps.json');stepmap={x['slot_id']:x for x in steps}
# Excerpts copied byte-for-byte. The untouched evidence is not duplicated in this smaller bundle.
examples=['x03s0_shallow_atom_alias__long_rule_01','x03s0_shallow_long__long_rule_01','x05s0_shallow_atom_alias__atom_alias_rule_04','x05s0_shallow_long__long_rule_04']
examples += [r['first_error_slot'] for r in rows if not r['success'] and r['arm'] in ('atom_alias__atom_alias','atom_tagged__atom_tagged')]
examples += [x['slot_id'] for x in steps if x['stage']=='final' and not x['valid']]
for sid in sorted(set(examples)):
 dest=O/'examples'/sid;dest.mkdir(parents=True,exist_ok=True)
 for name in ('request.wire.json','response.raw.json','dispatch.started.json'):
  shutil.copy2(R/'wire'/sid/name,dest/name)
 (dest/'raw_check.json').write_text(json.dumps(stepmap[sid],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for src,name in [('summary.ko.md','original_summary.ko.md'),('diagnostics.ko.md','original_diagnostics.ko.md'),('source/docs/PREREGISTRATION.ko.md','PREREGISTRATION_original.ko.md'),('source/data/protocol.json','protocol_original.json'),('status.json','original_status.json')]:shutil.copy2(R/src,V/name)
shutil.copy2('/mnt/data/v089_idcross_20260916_122755_207556_independent.json',V/'independent_provided.json')
source_hashes={f.relative_to(R/'source').as_posix():sha(f.read_bytes()) for f in (R/'source').rglob('*') if f.is_file() and '__pycache__' not in f.parts}
assert source_hashes==p['source_hashes']
assert read(V/'independent_provided.json')==read(V/'independent_rerun.json')
validation=dict(contract='v089-postrun-analysis-20260916',run_name=p['run_name'],evidence_sha256=sha(Path('/mnt/data/v089_idcross_20260916_122755_207556_evidence.zip').read_bytes()),plan_sha256=p['plan_sha256'],protocol_sha256=p['protocol_sha256'],raw_audit=audit,source_snapshot_unchanged=True,source_files=len(source_hashes),independent_rerun_identical=True,production_rerun=read(V/'production_baseline_rerun.json'),field_invariance=extra['field_invariance'],independent_aggregation=extra['independent_aggregation'],primary=extra['primary'],new_model_inference_calls=0,interpretation='A=過거 유효 facts와 지정 경로·ID 지원의 연속 생성; B=새 선택·새 facts의 기존 D 종단. 기존 8구조·2seed, 신규 holdout 없음.'.replace('過거','과거'))
(O/'ANALYSIS_VALIDATION_v089.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
styles=s['initial_id_styles']
graph_matrix='| 초기 ID ↓ / 후속 ID → | atom_alias | short | long | atom_tagged |\n|---|---:|---:|---:|---:|\n'
pair_matrix=graph_matrix
for ini in styles:
 graph_matrix+='| '+ini+' | '+' | '.join(f"{extra['matrices']['continuation/'+ini+'__'+out]['success']}/32" for out in styles)+' |\n'
 pair_matrix+='| '+ini+' | '+' | '.join(f"{extra['matrices']['continuation/'+ini+'__'+out]['pair_success']}/16" for out in styles)+' |\n'
first_table='| 조건 | 연속 성공 | 참조 실패가 최초인 graph | 전제 오류가 최초인 graph |\n|---|---:|---:|---:|\n'
for arm in ['atom_alias__short','short__short','atom_alias__long','long__long','short__long','long__short','short__atom_alias','long__atom_alias','atom_alias__atom_alias','atom_tagged__atom_tagged']:
 d=extra['reference_errors'][arm];g=extra['matrices']['continuation/'+arm]
 first_table+=f"| {arm.replace('__',' → ')} | {g['success']}/32 | {d['first_missing_parent']} | {d['first_premise_error']} |\n"
struct='| 구조 | alias 유지 | short 유지 | long 유지 | tagged 유지 | 주평가 효과 |\n|---|---:|---:|---:|---:|---:|\n'
for pid,delta in extra['primary_by_structure'].items():
 struct+='| '+pid+' | '+' | '.join(f"{extra['matrices']['continuation/'+sty+'__'+sty]['per_structure'][pid]['success']}/4" for sty in styles)+f' | {delta*100:+.2f}%p |\n'
usage='| 유지 조건 | 호출 | prompt_eval_count 합 | eval_count 합 | total_duration 합(초) |\n|---|---:|---:|---:|---:|\n'
for sty in styles:
 d=raw['usage']['continuation/'+sty+'__'+sty];usage+=f"| {sty} | {d['calls']} | {d['prompt_eval_count']:,} | {d['eval_count']:,} | {d['total_duration']/1e9:.3f} |\n"
report='''# v089 ID 4×4 교차 실험 — 실제 결과 분석·원응답 재검산

분석일: 2026-09-16 KST  
실행: `v089_idcross_20260916_122755_207556`  
근거: 첨부 evidence ZIP, independent JSON, evidence 내부의 사전 동결 protocol·원요청·원응답·v088 기준선. 외부 연구나 다른 모델 자료로 빈틈을 채우지 않았다.

## 1. 결론

**실행은 정상 완료됐고 사전 주평가는 +34.375%p였다. 같은 후속 중립 ID를 쓰면서 초기 facts의 ID를 atom_alias에서 같은 계열의 중립 ID로 바꾸자 참조 실패가 줄고 양방향 연속 생성이 개선됐다.**

4×4 전체를 보면 가장 높은 연속 성공은 `atom_alias → atom_alias` 29/32(양방향 13/16), 다음은 `atom_tagged → atom_tagged` 28/32(12/16)였다. 반면 `atom_alias → long`은 0/32, `atom_alias → short`는 5/32였다. 중립 ID에서 atom_alias로 바꾸는 역방향도 7/32·8/32로 낮았다. 즉 좋은 후속 ID 하나를 고르는 문제보다 **초기·후속의 원자–ID 대응 조합과 그 일관성**이 중요하다.

기존 D 종단 baseline은 선택 128/128, 실제 요구 D 종단 111/128, 양방향 48/64, 네 표시 전체 9/16이었다. 교차 진단에서 새 방법을 찾았지만, 그 방법이 새 선택·새 facts를 포함한 전체 D 종단에서 baseline보다 낫다는 대조까지 실행한 것은 아니다.

## 2. 실제 수행한 검산

| 검사 | 결과 |
|---|---:|
| evidence ZIP 멤버 | 19,596개 |
| MANIFEST 제외 파일 SHA-256 | 19,595/19,595 일치 |
| source snapshot | 146개 파일, 분석 전후 원형 유지 |
| action 시작/완료 | 3,888/3,888 |
| dispatch / 보존 응답 | 3,824/3,824 |
| 정상 HTTP·모델·종료·JSON Schema | 3,824/3,824 |
| 정상 조건부 skip | 32개 |
| runtime metadata checkpoint | 32개 모두 일치 |
| pending / 미관측 | 0 |
| 생산 summary 재실행 | 원본과 객체 전체 일치 |
| 제공된 독립 verifier 재실행 | verified=true, differences=[]; 제출 JSON과 전체 일치 |
| 별도 원응답 규칙 채점 | 2,800개; 국소 유효 판정 일치 |
| 별도 graph·D·trial 채점 | 640개; 불일치 0 |
| 별도 양방향 pair 집계 | 320개; 원본 집계 일치 |
| 별도 네 표시 bundle 집계 | 16개 |
| v088 원본 기준선 재검산·facts anchor 재선정 | 16개 anchor·115개 보존 소스 일치 |
| 분석 중 새 모델 추론 | 0회 |

3,888 action = 3,824 추론 + 32 경로 밖 조건부 skip + 32 metadata다. 규칙은 A 교차 진단 2,240개와 B baseline 560개다. 같은 응답의 여러 검산을 새 표본으로 더하지 않는다.

제공된 독립 verifier는 의미 판정·요청 재구성을 별도로 구현하지만 `tables089` 집계 및 `diagnostics089`를 생산과 공유한다. 이번 분석에서는 이를 고려해 **별도 원응답 채점으로 640개 outcome을 다시 만들고, 17개 군·320개 pair·사전 주평가·보조 대비·위험집합을 별도로 계산**해 대조했다.

오류 응답의 ID나 부모를 고치지 않았다. graph에서는 ID 중복, 부모 존재·중복, 등록된 규칙·결론, 직접 전제 multiset, 출력 순서·cycle, 최종 goal, goal ancestry, 실제 D를 재검사했다. 문서 속 실행 사실은 보존된 dispatch와 HTTP 원응답에 근거하며 별도 외부 실행 인증을 뜻하지 않는다.

## 3. 조건과 비교 가능성

Ollama 0.34.1, qwen3:4b-instruct 4.0B/Q4_K_M, 기존과 같은 모델 digest를 사용했다. seed는 64001001·64001002, temperature 0.7, top_p 0.8, top_k 20, repeat_penalty 1, num_ctx 8192, num_predict 4096이다. metadata의 최대 context 262144와 실제 num_ctx를 구분한다.

A는 기존 U01~U08의 두 경로, 두 seed, 16개 ID 조건에서 **지원받은 유효 초기 facts 이후의 연속 생성**을 평가한 512개 graph다. 경로와 각 규칙, 현재 출력 ID는 사전 계약으로 지정된다. B는 기존 two-stage 선택을 새로 수행하고 facts부터 새로 생성한 baseline 128개다. A/B는 이 실험의 평가 구분이지 상위 A/D/M 축 이름이 아니다.

초기 ID 방식: atom_alias는 ID=원자명, atom_tagged는 `node_원자명`, short는 `n0001`, long은 `v087_node_0001` 계열이다. 후속 출력에도 같은 네 방식을 적용했다.

독립적으로 확인한 통제는 다음과 같다.

- 초기 facts 512개 재명명: 순서·원자·사실 의미는 같고 ID만 지정 방식으로 변경.
- 후속 ID 2,240개: 원자·순번으로 별도 재구성해 요청과 일치.
- 동일한 후속 ID 방식의 초기 4군: 128세트에서 새 ID sequence가 동일.
- 128세트의 첫 요청: 초기 facts ID만 정규화하면 나머지 요청이 동일.
- 생성 요청 3,568개: 사전에 바꾼 초기 facts 이후에는 앞선 모델 원문이 그대로 history로 전달됨.

후속 단계의 요청 history 차이는 앞서 모델이 실제 생성한 출력의 차이를 포함한다. 이를 사후에 동일하게 맞춰 고치지 않았다. 이 실험은 그 연속 과정 전체의 효과를 측정한다. 모든 조건은 구조×seed 블록 내에서 순환 배치됐으며 신규 구조 holdout은 0개다.

## 4. 사전 주평가

주평가는 구조별로 `½ × [(short→short)-(atom_alias→short) + (long→long)-(atom_alias→long)]`의 양방향 성공률 차이를 계산한 뒤 8개 구조를 동일 가중한 값이다.

| 후속형 고정 | atom_alias 초기 | 같은 중립형 초기 | 양방향 차이 |
|---|---:|---:|---:|
| short | 0/16 | 5/16 | +31.25%p |
| long | 0/16 | 6/16 | +37.50%p |
| 두 계열 동일 가중 | — | — | **+34.375%p** |

단일 graph에서는 short 5/32→18/32, long 0/32→19/32다. short 대조는 기존 성공 5개를 유지하고 13개를 얻었다. long 대조는 기존 성공이 없었고 19개를 얻었다.

구조별 주평가 증가: U01 +25%p, U02 +50%p, U04 +50%p, U05 +100%p, U07 +50%p. U03·U06·U08은 0이다. 따라서 5개 구조에서 증가했고 3개는 양방향 단계에서 해결되지 않았다.

구조 하나씩 제외한 민감도 계산은 +25.00~+39.29%p다. 가장 큰 U05를 빼도 +25%p가 남았다. 이 범위는 신뢰구간이 아니다. 8개 구조·2seed의 고정 진단이며, 3,824회 호출을 독립 문제 수로 쓰거나 IID 모집단 p값으로 확장하지 않는다. 또한 대조군 양방향이 0이므로 ‘양방향 감소가 없다’ 자체는 강한 안정성 증거가 아니다.

## 5. 전체 4×4 결과

### 5.1 유효 연속 graph — 각 셀 32개

'''+graph_matrix+'''
### 5.2 shallow·deep 양방향 성공 — 각 셀 16쌍

'''+pair_matrix+'''
각 셀은 동일한 8구조×2seed×2방향을 다른 이름 조합으로 평가한 것이다. 16개 독립 문제 집합이 아니다. 사전 주평가와 16개 전체 셀의 기술적 비교를 구분한다.

## 6. 원인 해석: v088의 구조별 혼입을 줄였지만 단순한 하나의 법칙은 아니다

### 6.1 atom_alias에서 중립 ID로 전환하는 조건의 실패가 직접 재현됐다

v088에서는 초기 ID 유형이 구조·경로와 함께 달라져 유형별 대조가 제한됐다. v089는 모든 구조·경로·seed에 네 초기형을 교차했다. `atom_alias→long`의 32개 실패 전부와 `atom_alias→short`의 27개 실패 전부는 **없는 부모 ID 참조가 최초 오류**였다.

규칙 단위로는 각각 84개·79개에서 missing_parent가 발생했고, 이 모든 규칙의 누락 ID 문자열은 이미 존재하는 원자명과 일치했다. 이 수에는 이전 실패 후의 오류 전파가 포함되므로 graph 실패 수와 합산하지 않는다.

초기·후속 모두 long 또는 short로 통일하면 missing_parent는 0개였고, 남은 최초 실패는 전제 연결 오류였다. 따라서 초기 원자–ID 대응에 개입한 것이 후속 참조 오류와 종단 성공을 바꾼다는 증거가 됐다.

### 6.2 ‘이름이 섞이면 무조건 실패한다’는 설명은 맞지 않는다

`short→long`은 13/32, `long→short`는 12/32였다. 이들은 서로 다른 이름 계열이 섞이지만 atom_alias→중립형의 0/32·5/32보다 높다. `atom_tagged→long`은 20/32로 long→long 19/32보다 1개 많다. 따라서 이름 계열 혼용 그 자체만으로 전체 차이를 설명할 수 없다.

반대로 중립형에서 atom_alias로 바꾸는 역방향도 short→alias 7/32, long→alias 8/32였다. 후속 ID를 읽기 쉬운 원자명으로 바꾸는 것만으로는 충분하지 않다. 이 방향은 최초 전제 오류가 22개·19개로 많고 최초 참조 오류는 3개·5개였다. 전환 방향에 따라 실패 유형도 다르다.

**현재 가능한 결론은 원자–ID 대응 계약의 초기·후속 조합이 중요하다는 것**이다. 모델 내부의 attention, 학습된 복사 경향, 토큰화 등 어느 기제가 이 차이를 만들었는지는 직접 분리하지 않았다.

### 6.3 완전 동일 문자열만이 유리한 조건은 아니다

alias 유지 29/32 외에 tagged 유지도 28/32였다. tagged는 ID와 원자명이 완전히 같지는 않지만 원자명을 포함한다. 따라서 ‘ID=atom이어야만 가능하다’보다 **원자명을 식별할 수 있는 일관된 명명 체계가 유망하다**는 해석이 결과와 맞는다. 문자열 길이만의 효과를 분리한 실험은 아니다.

## 7. 최초 오류와 연속 단계

'''+first_table+'''
short 대조에서는 참조 실패 27개가 uniform에서 성공 13개와 전제 실패 14개로 나뉘었다. long 대조에서는 참조 실패 32개가 성공 19개와 전제 실패 13개로 나뉘었다. 따라서 전제 오류가 더 많이 집계된다는 사실만으로 uniform이 전제 판단을 악화시켰다고 결론 내리지 않는다. 개별 경로의 실패 유형 전이를 봐야 한다.

`atom_alias→long`과 `atom_alias→short` 모두 첫 규칙은 32/32 성공했다. 두 번째 규칙에서 각각 18/32가 처음 실패했다. 같은 단계에서 short→short는 2/32, long→long은 0/32가 실패했다. 첫 규칙 뒤 새 노드가 history에 들어간 다음 단계가 분기점이라는 기존 관찰이 재현됐다.

다만 모든 조합의 첫 규칙이 100%인 것은 아니다. tagged→alias는 첫 규칙부터 13개가 실패했고 tagged 유지에서도 첫 규칙 전제 누락 2개가 있었다. 따라서 ‘모든 이름 효과는 반드시 두 번째 이후에만 나타난다’고 일반화하지 않는다.

A 전체의 303개 실패 graph의 최초 오류는 참조 163개와 전제 140개였다. A final 지칭 실패 2개는 이미 앞 규칙에서 실패한 graph의 후속 오류다. 이를 별개의 실패 graph로 더하지 않는다.

## 8. 실제 원응답 사례

### 8.1 같은 U04 shallow의 두 번째 규칙

규칙은 `F83 AND F78 AND F85 → F58`이다. alias→long에서는 facts ID가 F83·F78인데 새 F85 노드의 ID는 v087_node_0004다. 모델은 `parents=["F83","F78","F85"]`를 출력했다. F85라는 ID는 없으므로 실패다.

long→long의 같은 위치에서는 `parents=["v087_node_0002","v087_node_0003","v087_node_0004"]`로 정확히 연결했다. 두 조건의 현재 출력 ID는 모두 v087_node_0005다. 즉 현재 ID 지정 준수와 후속 parent 재참조는 분리된다. 요청과 응답은 `examples/x03s0_shallow_*_rule_01/`에 그대로 보존했다.

### 8.2 U06의 직접 전제 H15 누락

규칙은 `H15 AND H02 AND H44 → H74`다. long 유지에서는 H02·H44에 해당하는 ID만 부모로 출력해 H15를 누락했다. alias 유지에서는 `parents=["H15","H02","H44"]`로 맞았다. 같은 두 seed에서 U06 shallow는 중립 유지 두 군 모두 0/2, alias 유지와 tagged 유지는 모두 2/2였다.

이는 이전에 전제 오류로 남았던 경로도 표상을 바꾸면 성공할 수 있음을 보여준다. 하지만 별도의 원인 기제를 식별한 것은 아니며, 전제 오류가 전부 ID 문제라고 환원하지 않는다.

## 9. 높은 성과의 두 의미 ID 조건에도 서로 다른 실패가 남았다

### atom_alias 유지: 3개 실패

- U07 deep / seed 64001001: `I91 AND I43 → I32`에서 부모를 I77·I43으로 출력. I91 대신 다른 사실 I77을 선택했다.
- U08 deep / 두 seed: `J07 AND J31 AND J03 → J74`에서 J03을 누락했다.

세 오류는 전부 두 번째 규칙에서 처음 발생했다. ID 조회를 원자명 복사로 단순화해도 잘못된 직접 전제 선택·누락은 남는다. 이 조건은 U01~U06에서 각 4/4 성공했지만 U07 3/4, U08 2/4였다.

### atom_tagged 유지: 4개 실패

- U03의 두 경로·seed 조합에서 첫 단항 규칙의 parents를 빈 배열로 출력했다.
- U06 deep의 두 seed에서 `node_H28`, `node_H96` 대신 `node_28`, `node_96`를 출력했다. 접두부는 유지했지만 원자명의 H를 빠뜨려 존재하지 않는 ID가 됐다.

따라서 모든 uniform 조건에서 참조 오류가 0이라는 법칙은 아니다. 이번 short/long/alias 유지에서는 0이었지만 tagged 유지에서는 2개였다.

두 의미 ID 군의 실패 경로는 겹치지 않았다. 둘 다 성공 25개, alias만 성공 4개, tagged만 성공 3개다. 이것은 경로별 표상 민감성에 대한 추가 관찰이다. 둘을 사후에 합쳐 32/32를 하나의 생성기 성과로 보고하지 않는다. 두 번 실행해 검증기로 선택하는 전략은 호출량과 성공 정의가 다른 별도 실험이다.

### 구조별 유지 조건의 단일 경로 결과

'''+struct+'''
주평가 열은 중립 유지와 alias 초기→중립 후속의 양방향 차이이며, 앞 네 열은 단일 graph 성공이다. 서로 다른 분모를 혼동하지 않는다.

## 10. B — 기존 D 종단 기준선

| 지표 | v088 r2 | v089 |
|---|---:|---:|
| 외부 정확 D 사용 two-stage 선택 | 128/128 | 128/128 |
| 새 facts부터 실제 요구 D 종단 | 112/128 | 111/128 |
| 양방향 종단 | 49/64 | 48/64 |
| 네 표시 전체 성공 | 10/16 | 9/16 |

baseline의 핵심 수준은 비슷하게 관측됐지만 성공 집합이 완전히 동일하지는 않았다. 같은 128개 경로를 대조하면 둘 다 성공 106개, v088만 성공 6개, v089만 성공 5개, 둘 다 실패 11개다.

v089 baseline의 17개 실패는 모두 최초 전제 연결 오류다. U01 deep 2개, U03 shallow 5개·deep 1개, U06 shallow 6개, U08 shallow 3개다. 초기 facts와 final goal 지칭은 각 128/128이므로 단순 최종 답만 검사하면 이 실패를 놓친다.

깊이별 결과:

| 요구 D | baseline 성공 |
|---|---:|
| 2 | 24/24 |
| 3 | 32/48 |
| 4 | 40/40 |
| 5 | 15/16 |

깊이가 클수록 일관되게 실패하는 패턴은 아니다. D와 구조·전제 조합이 함께 다르므로 깊이의 독립 인과효과로도 해석하지 않는다.

### 동일 입력의 실제 재현성

v088과 비교한 compare·select 각 128개는 요청과 reply content가 모두 동일했다. facts 128개는 요청이 모두 같지만 content가 동일한 것은 110개였다. rule은 560개 중 요청이 동일한 것이 333개, 그중 content까지 동일한 것은 255개였다. final은 128개 중 요청이 동일한 32개가 모두 같은 content를 냈다.

이는 같은 보존 요청에서도 일부 생성 content가 달랐다는 관찰이다. 공백 차이까지 포함하는 바이트 비교이며, 곧바로 의미 차이나 특정 runtime 원인으로 해석하지 않는다. source·모델·요청 조건이 유지됐다는 사실과 응답이 완전히 동일하다는 주장을 구분한다. 변경 원인으로 업데이트·GPU·캐시 등을 특정하지 않았다.

## 11. 계산량 참고

'''+usage+'''
각 군 호출은 규칙 140회+final 32회다. alias와 tagged 유지의 응답 시간 합은 각각 약 112.883초·137.569초이고 중립 long 유지는 약 168.036초다. 이 실행에서는 의미 ID 두 군의 성과가 높으면서 토큰·응답시간 누적도 long 유지보다 작았다.

전체 응답 prompt_eval_count 합 4,104,814, eval_count 합 160,586, total_duration 합 2,822.657초다. 첫 응답 2026-09-16 12:31:02.480 KST, 마지막 13:20:06.030 KST로 응답 시각 범위는 약 49분 3.549초다. 이는 launcher 전체 경과시간이나 청구비용이 아니다. 입력 합에는 반복 history가 포함되며 고유 토큰 수가 아니다. 비교된 처리량은 이 모델·실행의 관측값이다.

## 12. 연구상 의미와 다음 판단

이번 결과는 v088의 ‘초기 ID 유형과 구조가 함께 달랐다’는 공백을 동일 구조의 4×4 교차로 줄였다. 사전 주평가가 양수였고, 참조 오류에서 성공 또는 전제 오류로 이동하는 대응 경로가 확인됐다. 따라서 기존 실패를 모델 크기나 추론 깊이 하나로 묶기보다 **표현 계약의 전환, 식별자 참조, 직접 전제 연결**로 나눠 분석할 근거가 강화됐다.

또한 국소 alias 140/140에서 곧바로 종단 100%를 가정하지 않고 실제 연속 생성으로 확장한 결과가 29/32였다. 유망한 효과는 이어졌지만 국소와 연속 성공은 다르다는 기준도 유지됐다.

현재의 직접 성과는 고정된 primitive inference system에서 외부 proof DAG의 D를 다시 계산한 결과다. 교차군은 유효 초기 facts·경로·규칙·현재 ID를 지원받았다. 따라서 29/32를 새 facts·선택 포함 D 종단의 개선 수치로 바꾸지 않는다.

다음 단계에서 우선 확인할 것은 **baseline과 의미 ID 유지 두 군을 같은 ‘새 선택·새 facts’ 출발점에서 비교하는 것**이다. 지원 정보·부모 자유도·실패 채점·모델 호출수·원응답 무보정 원칙을 맞춰야 한다. 그 절차를 사전에 동결한 뒤 신규 구조에서 재현해야 기존 구조에 맞춘 개선인지도 구분할 수 있다. 현재 baseline을 즉시 교체할 종단 대조는 아직 없다.

이 문서는 실제 v089 결과 분석이다. 다음 버전 설계·소스나 추가 모델 실행을 생성하지 않았다.

## 13. 근거와 재현 파일

원본 evidence SHA-256:
`'''+validation['evidence_sha256']+'''`

실제 plan SHA-256:
`'''+p['plan_sha256']+'''`

protocol SHA-256:
`'''+p['protocol_sha256']+'''`

`ANALYSIS_VALIDATION_v089.json`에 수행한 검산과 기준선 정보를 기록했다. `validation/`에는 별도 640개 trial, 2,800개 규칙을 포함한 step 검사, 320개 pair, 최초 실패·오류 전이·조건 불변성·공식 verifier 및 생산 재실행 결과가 있다. `examples/`에는 사례 원요청·원응답·dispatch를 보존했다. 재현 명령은 `README_검산재현.ko.md`에 있다.

주의: 원 evidence source 디렉터리에 분석 코드를 추가하면 동결 해시가 변한다. 별도 분석 폴더에서 스크립트를 실행한다.
'''
(O/'v089_결과분석_2026-09-16.md').write_text(report,encoding='utf-8')
readme='''# v089 원응답 검산 재현

원본 evidence ZIP을 별도 폴더 `<EVIDENCE>`에 구조를 바꾸지 않고 푼다. 분석 코드/출력은 원본 source 폴더 밖에 둔다. Python과 jsonschema가 필요하다. 검산은 오프라인이며 모델 추론·서버 조회·다운로드를 하지 않는다.

```text
python -X utf8 -B <EVIDENCE>/source/verify089.py <원본_evidence.zip>
python -X utf8 -B code/recheck_production_v089.py --evidence-dir <EVIDENCE> --out <검산폴더>
python -X utf8 -B code/audit_raw_v089.py --evidence-dir <EVIDENCE> --out <검산폴더>
python -X utf8 -B code/additional_analysis_v089.py --evidence-dir <EVIDENCE> --raw-audit-dir <검산폴더> --out <검산폴더>
```

두 번째 명령은 원본에 내장된 v088 기준선의 verifier도 실행한다. 세 번째 코드는 이전 v088용 별도 raw audit을 v089에 맞춰 수정한 것이며, 생산/제공된 독립 의미 채점 모듈을 import하지 않는다. 네 번째 코드는 세 번째 원응답 판정으로 집계·원문 불변성·최초 오류 전이를 계산한다. 저장된 결과와 시험 횟수를 새 표본으로 세지 않는다.

`validation/independent_rerun.json`은 제공된 verifier의 실제 재실행 출력이다. `raw_audit_result.json`은 별도 원응답 채점 결과, `additional_metrics.json`은 별도 주평가·pair 집계와 통제 검사다. 원본 evidence 약 161MiB는 이 분석 ZIP에 중복 포함하지 않았다.

`package_report_v089.py`는 이 세션의 폴더 경로로 보고서를 조립한 보조 스크립트이며 재검산에는 필요 없다. 연구 source는 변경되지 않았다. `SHA256SUMS.json`은 자기 자신을 제외한 분석 묶음 각 파일의 SHA-256이다.
'''
(O/'README_검산재현.ko.md').write_text(readme,encoding='utf-8')
# Exclude unused imported prior scripts, not any evidence.
for f in (O/'code').glob('prior_*.py'):f.unlink()
sums={f.relative_to(O).as_posix():sha(f.read_bytes()) for f in sorted(O.rglob('*')) if f.is_file() and f.name!='SHA256SUMS.json'}
(O/'SHA256SUMS.json').write_text(json.dumps(sums,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
zpath=Path('/mnt/data/v089_결과분석_검산자료_2026-09-16.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(O.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(O).as_posix())
with zipfile.ZipFile(zpath) as z:
 for n,h in json.loads(z.read('SHA256SUMS.json')).items():assert sha(z.read(n))==h
print(json.dumps(dict(report=str(O/'v089_결과분석_2026-09-16.md'),report_chars=len(report),archive=str(zpath),archive_bytes=zpath.stat().st_size,archive_sha256=sha(zpath.read_bytes()),files=len(sums)+1),ensure_ascii=False,indent=2))
