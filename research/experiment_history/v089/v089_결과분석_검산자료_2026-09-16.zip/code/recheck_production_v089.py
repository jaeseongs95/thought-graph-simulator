import sys,json,hashlib,zipfile,argparse
from pathlib import Path
parser=argparse.ArgumentParser(description='번들에 보존된 생산 집계와 v088 원본 기준선을 재검산한다.')
parser.add_argument('--evidence-dir',type=Path,required=True)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args();R=args.evidence_dir.resolve();O=args.out.resolve();O.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(R/'source'))
import core089,report089,baseline089
p=core089.load((R/'plan.json').read_bytes());events=[core089.load(x) for x in (R/'records/events.jsonl').read_bytes().splitlines()];records={e['action']['id']:core089.load((R/'records'/(e['action']['id']+'.json')).read_bytes()) for e in events};responses={x.parent.name:x.read_bytes() for x in (R/'wire').glob('*/response.raw.json')}
got=report089.summarize(p,records,responses,'complete');assert core089.exact(got,core089.load((R/'summary.json').read_bytes()))
print('production summary exact match',flush=True)
base=baseline089.validate_inputs(R/'baseline/v088_evidence.zip',run_verifier=True)
result={'production_summary_identical':True,'baseline_anchor_verification':base}
(O/'production_baseline_rerun.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(R/'baseline/v088_evidence.zip') as z:
 for n in ['summary.json','summary.ko.md','plan.json','diagnostics.json']:
  if n in z.namelist():(O/('v088_'+n)).write_bytes(z.read(n))
print(json.dumps(base,ensure_ascii=False,indent=2))
