"""첨부된 실제 HTTP 원응답에 대한 별도 무보정 채점. 실험 채점 모듈을 import하지 않는다."""
from pathlib import Path
from collections import Counter, defaultdict
import json, hashlib, csv, zipfile, sys, math, argparse
from datetime import datetime
import jsonschema
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--evidence-dir',type=Path,required=True,help='evidence ZIP을 원형 그대로 풀어 둔 디렉터리')
parser.add_argument('--out',type=Path,required=True,help='새 검산 출력 디렉터리')
args=parser.parse_args()
ROOT=args.evidence_dir.resolve(); OUT=args.out.resolve(); OUT.mkdir(parents=True,exist_ok=True)
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(b): return hashlib.sha256(b).hexdigest()
def save(name,x): (OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def pairs_hook(ps):
 d={}
 for k,v in ps:
  assert k not in d,('duplicate JSON key',k)
  d[k]=v
 return d
def load_str(x): return json.loads(x,object_pairs_hook=pairs_hook,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
p=read(ROOT/'plan.json');s=p['protocol'];sm=read(ROOT/'summary.json')
manifest=read(ROOT/'MANIFEST.json')['file_hashes']
assert all(sha((ROOT/k).read_bytes())==v for k,v in manifest.items())
assert set(manifest)=={x.relative_to(ROOT).as_posix() for x in ROOT.rglob('*') if x.is_file()}-{'MANIFEST.json'}
print('Manifest verified',len(manifest),flush=True)
req={};data={};raw={};obj={};rec={};schemas={};schema_fail=[]
slots={o['id']:o for o in p['slots']};trials={t['id']:t for t in p['trials']};bytrial=defaultdict(list)
for o in p['slots']:
 sid=o['id'];rec[sid]=read(ROOT/'records'/f'{sid}.json')
 if rec[sid]['kind']=='skip':continue
 q=read(ROOT/'wire'/sid/'request.wire.json');r=read(ROOT/'wire'/sid/'response.raw.json')
 assert rec[sid]['http_status']==200 and rec[sid]['error'] is None
 assert r['done'] is True and r['done_reason']=='stop' and r['model']==s['model']
 assert r['message']['role']=='assistant'
 v=load_str(r['message']['content']);key=json.dumps(q['format'],sort_keys=True)
 if key not in schemas:schemas[key]=jsonschema.Draft202012Validator(q['format'])
 es=list(schemas[key].iter_errors(v))
 if es:schema_fail.append((sid,[e.message for e in es]))
 req[sid]=q;raw[sid]=r;obj[sid]=v;data[sid]=load_str(q['messages'][0]['content'].split('\n\ninput: ',1)[1]);bytrial[o['trial_id']].append(o)
assert not schema_fail,schema_fail

def history(d):
 ns=[]
 for h in d['history']:
  x=load_str(h['content']);ns.extend(x['nodes'] if 'nodes' in x else [x['node']])
 return ns

def node_check(problem,before,n,rid):
 idx=defaultdict(list)
 for x in before:idx[x['id']].append(x)
 rules={r['id']:r for r in problem['rules']};r=rules[rid];errors=[]
 if n['id'] in idx:errors.append('duplicate_node_id')
 if n['rule']!=rid:errors.append('requested_rule_mismatch')
 if n['atom']!=r['conclusion']:errors.append('wrong_atom')
 if len(n['parents'])!=len(set(n['parents'])):errors.append('duplicate_parent')
 missing=[x for x in n['parents'] if not idx.get(x)]
 if missing:errors.append('missing_parent')
 if any(len(idx[x])>1 for x in n['parents']):errors.append('ambiguous_parent_id')
 actual=Counter(idx[x][0]['atom'] for x in n['parents']) if all(len(idx[x])==1 for x in n['parents']) else None
 expected=Counter(r['premises'])
 if actual is not None and expected!=actual:errors.append('premise_counter_mismatch')
 return dict(valid=not errors,errors=sorted(errors),missing_ids=missing,
    missing_ids_all_are_existing_atoms=bool(missing) and all(x in {a['atom'] for a in before} for x in missing),
    missing_atoms=None if actual is None else list((expected-actual).elements()),
    extra_atoms=None if actual is None else list((actual-expected).elements()),
    parents_count_ok=len(n['parents'])==len(r['premises']),
    requires_prior_rule=any(x['rule'] is not None and x['atom'] in r['premises'] for x in before))

def route_metrics(problem,path):
 depths={f:0 for f in problem['facts']};rules={r['id']:r for r in problem['rules']}
 for rid in path:
  r=rules[rid];assert all(a in depths for a in r['premises']);depths[r['conclusion']]=1+max(depths[a] for a in r['premises'])
 return {'D':depths[problem['goal']],'W':len(path)}

profiles={};problems={x['id']:x for x in s['problems']}
for pid,problem in problems.items():
 profiles[pid]={k:route_metrics(problem,v) for k,v in s['reference_plans'][pid].items()}
 for i,k in enumerate(s['reference_conditions']):
  assert profiles[pid][k]=={'D':s['frozen_profiles'][pid][i]['goal_depth'],'W':s['frozen_profiles'][pid][i]['rule_count']}

def graph_check(problem,ns,final):
 """모든 노드를 검사한다. ID 덮어쓰기나 goal 비조상 노드 제거를 하지 않는다."""
 idx=defaultdict(list)
 for n in ns:idx[n['id']].append(n)
 errors=[]
 if any(len(v)!=1 for v in idx.values()):errors.append('duplicate_id')
 if len(idx.get(final,[]))!=1:errors.append('missing_or_ambiguous_final')
 elif idx[final][0]['atom']!=problem['goal']:errors.append('wrong_goal')
 rules={r['id']:r for r in problem['rules']};facts=set(problem['facts'])
 for n in ns:
  ps=n['parents']
  if len(ps)!=len(set(ps)):errors.append('duplicate_parent')
  if any(len(idx.get(x,[]))!=1 for x in ps):errors.append('missing_or_ambiguous_parent')
  if n['rule'] is None:
   if ps or n['atom'] not in facts:errors.append('invalid_fact')
  elif n['rule'] not in rules:errors.append('unregistered_rule')
  else:
   r=rules[n['rule']]
   if n['atom']!=r['conclusion']:errors.append('wrong_atom')
   if all(len(idx.get(x,[]))==1 for x in ps) and Counter(idx[x][0]['atom'] for x in ps)!=Counter(r['premises']):errors.append('premise_counter_mismatch')
 if errors:return dict(valid=False,depth=None,errors=sorted(set(errors)))
 # Topological traversal both enforces output order and excludes cycles.
 dep={}
 for n in ns:
  if any(x not in dep for x in n['parents']):errors.append('non_topological_or_cycle');break
  dep[n['id']]=0 if n['rule'] is None else 1+max(dep[x] for x in n['parents'])
 anc=set();todo=[final]
 while todo:
  x=todo.pop()
  if x in anc:continue
  anc.add(x);todo.extend(idx[x][0]['parents'])
 if anc!=set(idx):errors.append('extra_unused_node')
 return dict(valid=not errors,depth=dep.get(final) if not errors else None,errors=errors)

steps=[];stepmap={}
for sid,o in slots.items():
 if sid not in obj or o['stage'] not in ('facts','rule','final'):continue
 t=trials[o['trial_id']];d=data[sid];v=obj[sid];before=history(d)
 base=dict(slot_id=sid,trial_id=t['id'],phase=t['phase'],arm=t['generator_arm'],problem_id=t['problem_id'],seed=t['seed'],condition=t['condition'],stage=o['stage'],position=o['rule_position'])
 if o['stage']=='rule':
  check=node_check(d['problem'],before,v['node'],d['operation']['requested_rule_id']);base.update(check)
  base.update(support_ok='allocated_node_id' not in d or v['node']['id']==d['allocated_node_id'],node=v['node'],history=before,requested_rule=d['operation']['requested_rule'])
 elif o['stage']=='facts':
  ns=v['nodes'];errs=[]
  if Counter(x['atom'] for x in ns)!=Counter(d['problem']['facts']):errs.append('initial_fact_multiset')
  if any(x['parents'] or x['rule'] is not None for x in ns):errs.append('initial_fact_shape')
  if len({x['id'] for x in ns})!=len(ns):errs.append('duplicate_node_id')
  base.update(valid=not errs,errors=errs,support_ok=True)
 else:
  matches=[x for x in before if x['id']==v['final_node_id']];errs=[]
  if len(matches)!=1:errs.append('missing_or_ambiguous_final')
  elif matches[0]['atom']!=d['problem']['goal']:errs.append('wrong_goal')
  base.update(valid=not errs,errors=errs,support_ok=True)
 steps.append(base);stepmap[sid]=base

rows=[];differences=[];declared={r['trial_id']:r for r in sm['rows']}
for t in p['trials']:
 pid=t['problem_id'];own=[o for o in bytrial[t['id']] if o['stage'] in ('facts','rule','final')];checks=[stepmap[o['id']] for o in own]
 r={k:t[k] for k in ('id','unit_id','problem_id','seed','phase','generator_arm','condition')};r['trial_id']=r.pop('id');r['arm']=r.pop('generator_arm');r.update(base_pair_id=t['base_pair_id'],initial_id_style=t.get('initial_id_style'),output_id_style=t.get('output_id_style'))
 selection=True
 if t['phase']=='rename_probe':
  r.update(success=checks[0]['valid'],depth=None,target_D=None,graph_valid=None,first_error=checks[0]['errors'] or None)
  expected=declared[t['id']]['probe_success']
 else:
  if t['phase']=='continuation':
   ns=history(data[own[0]['id']]);path=t['route_rule_ids'];expected=declared[t['id']]['continuation_success']
  else:
   ns=[];path=data[own[0]['id']]['provided_route_plan']['rule_ids'];expected=declared[t['id']]['end_to_end_success']
   ci=t['comparison_slot_id'];si=t['selection_slot_id'];dc=data[ci];ds=data[si]
   target=(min if dc['direction']=='min' else max)(dc['values']);cv=obj[ci]['target_value'];candidate=obj[si]['candidate_id']
   cvtable={x['candidate_id']:load_str(x['content'])['goal_depth'] for x in ds['candidate_measurements']}
   selection=cv==target and candidate in cvtable and cvtable[candidate]==cv and load_str(ds['value_original'])==obj[ci]
   assert data[own[0]['id']]['provided_route_plan']['candidate_id']==candidate
   r.update(selection_success=selection,comparison_value=cv,candidate_id=candidate,base_pair_id=t['base_pair_id'],order=t['candidate_order_index'],labels=t['id_assignment_index'])
  initial_count=len(ns);final=None
  for o in own:
   v=obj[o['id']]
   if o['stage']=='facts':ns.extend(v['nodes'])
   elif o['stage']=='rule':ns.append(v['node'])
   else:final=v['final_node_id']
  g=graph_check(problems[pid],ns,final)
  target=(min if t['condition']=='shallow' else max)(v['D'] for v in profiles[pid].values());rv=route_metrics(problems[pid],path)
  semantic=g['valid'] and all(c['valid'] for c in checks) and [n['rule'] for n in ns if n['rule'] is not None]==path and g['depth']==target==rv['D'] and sum(n['rule'] is not None for n in ns)==rv['W']
  support=all(c['support_ok'] for c in checks)
  fail=next((c for c in checks if not c['valid'] or not c['support_ok']),None)
  r.update(success=bool(semantic and support and selection),graph_valid=g['valid'],semantic_success=semantic,support_ok=support,
    depth=g['depth'],target_D=target,pair_id=t['pair_id'],first_error=None if fail is None else fail['errors'],first_error_slot=None if fail is None else fail['slot_id'],
    first_error_stage=None if fail is None else fail['stage'],first_error_position=None if fail is None else fail['position'])
  if g['valid'] != declared[t['id']]['graph_result']['strict_valid'] or g['depth']!=declared[t['id']]['actual_D']:differences.append((t['id'],'graph',g,declared[t['id']]['graph_result']))
 if r['success']!=expected:differences.append((t['id'],'outcome',r['success'],expected))
 rows.append(r)
for row in sm['rows']:
 for declared_step in row['step_checks']:
  sid=declared_step['id']
  if sid in stepmap:
   if stepmap[sid]['valid'] != declared_step['valid']:
    differences.append((sid,'step validity'))
assert not differences,differences[:5]

def counts(rs):return {'n':len(rs),'success':sum(r['success'] for r in rs)}
results={}
for phase in s['phases']:
 for arm in sorted({r['arm'] for r in rows if r['phase']==phase}):
  subset=[r for r in rows if r['phase']==phase and r['arm']==arm];st=[r for r in steps if r['phase']==phase and r['arm']==arm];rr=[x for x in st if x['stage']=='rule']
  result=counts(subset);result.update(rule_count=len(rr),rule_valid=sum(x['valid'] for x in rr),rule_support=sum(x['support_ok'] for x in rr),rule_error_codes=dict(Counter(e for x in rr for e in x['errors'])),missing_parent_rules=sum('missing_parent' in x['errors'] for x in rr),missing_parent_rules_all_atoms=sum(x['missing_ids_all_are_existing_atoms'] for x in rr))
  if phase!='rename_probe':
   result.update(first_error_codes=dict(Counter(e for r in subset for e in (r['first_error'] or []))),first_error_positions=dict(Counter(str(r['first_error_position']) for r in subset if not r['success'])),first_rule_valid=sum(x['valid'] for x in rr if x['position']==0),first_rule_count=sum(x['position']==0 for x in rr),
     by_depth={str(d):counts([r for r in subset if r['target_D']==d]) for d in sorted({r['target_D'] for r in subset})})
  results[phase+'/'+arm]=result

matched={}
for contrast in s['primary_components']+s['secondary_comparisons']:
 aa,bb=contrast
 ar={r['unit_id']:r for r in rows if r['phase']=='continuation' and r['arm']==aa}
 br={r['unit_id']:r for r in rows if r['phase']=='continuation' and r['arm']==bb}
 assert ar.keys()==br.keys()
 matched[aa+'->'+bb]=dict(Counter(('both_success' if ar[k]['success'] and br[k]['success'] else 'loss' if ar[k]['success'] else 'gain' if br[k]['success'] else 'both_failure') for k in ar))

usage={};timestamps=[]
for sid,r in raw.items():
 o=slots[sid];t=trials[o['trial_id']];arm='shared_selection' if o['stage'] in ('compare','select') else t['generator_arm'];k=t['phase']+'/'+arm
 u=usage.setdefault(k,Counter());u['calls']+=1
 for field in ['prompt_eval_count','eval_count','total_duration','eval_duration','prompt_eval_duration','prompt_eval_cached_count']:
  u[field]+=r.get(field,0)
 timestamps.append(r['created_at'])

checks={'manifest_files_verified':len(manifest),'manifest_differences':0,'http_responses':len(raw),'schema_checks':len(raw),'schema_failures':0,'unobserved':0,
 'trial_outcomes_recomputed':len(rows),'trial_disagreements':len(differences),'raw_rule_checks':sum(x['stage']=='rule' for x in steps),'full_graphs_recomputed':sum(r['phase']!='rename_probe' for r in rows),
 'actual_qwen_inference_added_by_this_audit':0,'first_response_timestamp':min(timestamps),'last_response_timestamp':max(timestamps),
 'source':'separate script; no production or provided independent semantic module imports', 'plan_sha256':p['plan_sha256']}
save('raw_audit_result.json',checks);save('derived_metrics.json',dict(results=results,matched=matched,usage=usage,profiles=profiles));save('raw_audit_trials.json',rows)
save('raw_rule_failures.json',[x for x in steps if not x['valid']]);save('raw_steps.json',steps)
keys=sorted(set().union(*(r.keys() for r in rows)))
with (OUT/'raw_audit_trials.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,keys);w.writeheader()
 for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()})
print(json.dumps(checks,indent=2));print(json.dumps(dict(results=results,matched=matched),ensure_ascii=False,indent=2))
