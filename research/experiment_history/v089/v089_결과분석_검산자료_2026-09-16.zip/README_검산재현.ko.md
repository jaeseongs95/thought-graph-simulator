# v089 원응답 검산 재현

원본 evidence ZIP을 별도 폴더 `<EVIDENCE>`에 구조를 바꾸지 않고 푼다. 분석 코드/출력은 원본 source 폴더 밖에 둔다. Python과 jsonschema가 필요하다. 검산은 오프라인이며 모델 추론·서버 조회·다운로드를 하지 않는다.

```text
python -X utf8 -B <EVIDENCE>/source/verify089.py <원본_evidence.zip>
python -X utf8 -B code/recheck_production_v089.py --evidence-dir <EVIDENCE> --out <검산폴더>
python -X utf8 -B code/audit_raw_v089.py --evidence-dir <EVIDENCE> --out <검산폴더>
python -X utf8 -B code/additional_analysis_v089.py --evidence-dir <EVIDENCE> --raw-audit-dir <검산폴더> --out <검산폴더>
```

두 번째 명령은 원본에 내장된 v088 기준선의 verifier도 실행한다. 세 번째 코드는 이전 v088용 별도 raw audit을 v089에 맞춰 수정한 것이며, 생산/제공된 독립 의미 채점 모듈을 import하지 않는다. 네 번째 코드는 세 번째 원응답 판정으로 집계·원문 불변성·최초 오류 전이를 계산한다. 저장된 결과와 시험 횟수를 새 표본으로 세지 않는다.

`validation/independent_rerun.json`은 제공된 verifier의 실제 재실행 출력이다. `raw_audit_result.json`은 별도 원응답 채점 결과, `additional_metrics.json`은 별도 주평가·pair 집계와 통제 검사다. 원본 evidence 약 161MiB는 이 분석 ZIP에 중복 포함하지 않았다.

`package_report_v089.py`는 이 세션의 폴더 경로로 보고서를 조립한 보조 스크립트이며 재검산에는 필요 없다. 연구 source는 변경되지 않았다. `SHA256SUMS.json`은 자기 자신을 제외한 분석 묶음 각 파일의 SHA-256이다.
