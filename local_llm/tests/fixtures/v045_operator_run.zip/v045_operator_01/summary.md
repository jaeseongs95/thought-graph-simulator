# 로컬 LLM 분리 교정 결과

실험 식별 해시: `d5f2d76eaeadff369a97a49e398925f6ec9c67ad77b471ff36de5624f959e5e3`

배정 16건 / 기록 16건 / 교정 과제 성공 15건

| 교정 과제 | 상태 |
| --- | --- |
| criterion_fact_not_goal__v045_and_not_b | accepted |
| criterion_neither__v045_and_not_b | accepted |
| criterion_fact_not_goal__v045_and_ab | accepted |
| criterion_goal_not_fact__v045_not_b | accepted |
| criterion_neither__v045_not_b | accepted |
| criterion_goal_is_fact__v045_copy_a | accepted |
| criterion_goal_not_fact__v045_and_not_b | invalid_task |
| criterion_neither__v045_and_ab | accepted |
| criterion_fact_not_goal__v045_not_b | accepted |
| criterion_goal_not_fact__v045_and_ab | accepted |
| criterion_goal_is_fact__v045_not_b | accepted |
| criterion_goal_not_fact__v045_copy_a | accepted |
| criterion_neither__v045_copy_a | accepted |
| criterion_goal_is_fact__v045_and_not_b | accepted |
| criterion_fact_not_goal__v045_copy_a | accepted |
| criterion_goal_is_fact__v045_and_ab | accepted |

## 실행 완료와 성능 판정

실행 완료: True / 전 조건 통과 여부: False
전 조건 통과 여부가 False여도 일부 과제는 성공할 수 있다. 위 성공 건수와 구성요소별 결과를 함께 본다.
완료됐다는 이유로 모델의 실패를 성공으로 바꾸지 않는다.
프롬프트 프로필: `factorized-v4`

## 모델 실제값과 기대값

task_checks의 true/false는 일치 여부다. 모델이 출력한 판정값은 아래 실제값 열이다.
null은 해당 전제의 실패로 평가할 수 없음을 뜻한다.

| 과제 | 필드 | 실제값 | 기대값 | 일치 |
| --- | --- | --- | --- | --- |
| criterion_fact_not_goal__v045_and_not_b | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Ca"} | {"probe_atom": "Ca", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_fact_not_goal__v045_and_not_b | source.primitives | {"in_facts": true, "same_as_goal": false} | {"same_as_goal": false, "in_facts": true} | True |
| criterion_fact_not_goal__v045_and_not_b | input_projection | {"a": false, "b": true} | {"a": false, "b": true} | True |
| criterion_fact_not_goal__v045_and_not_b | operator.value | false | false | True |
| criterion_neither__v045_and_not_b | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Cz"} | {"probe_atom": "Cz", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_neither__v045_and_not_b | source.primitives | {"in_facts": false, "same_as_goal": false} | {"same_as_goal": false, "in_facts": false} | True |
| criterion_neither__v045_and_not_b | input_projection | {"a": false, "b": false} | {"a": false, "b": false} | True |
| criterion_neither__v045_and_not_b | operator.value | false | false | True |
| criterion_fact_not_goal__v045_and_ab | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Ca"} | {"probe_atom": "Ca", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_fact_not_goal__v045_and_ab | source.primitives | {"in_facts": true, "same_as_goal": false} | {"same_as_goal": false, "in_facts": true} | True |
| criterion_fact_not_goal__v045_and_ab | input_projection | {"a": false, "b": true} | {"a": false, "b": true} | True |
| criterion_fact_not_goal__v045_and_ab | operator.value | false | false | True |
| criterion_goal_not_fact__v045_not_b | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Cc"} | {"probe_atom": "Cc", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_goal_not_fact__v045_not_b | source.primitives | {"in_facts": false, "same_as_goal": true} | {"same_as_goal": true, "in_facts": false} | True |
| criterion_goal_not_fact__v045_not_b | input_projection | {"a": true, "b": false} | {"a": true, "b": false} | True |
| criterion_goal_not_fact__v045_not_b | operator.value | true | true | True |
| criterion_neither__v045_not_b | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Cz"} | {"probe_atom": "Cz", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_neither__v045_not_b | source.primitives | {"in_facts": false, "same_as_goal": false} | {"same_as_goal": false, "in_facts": false} | True |
| criterion_neither__v045_not_b | input_projection | {"a": false, "b": false} | {"a": false, "b": false} | True |
| criterion_neither__v045_not_b | operator.value | true | true | True |
| criterion_goal_is_fact__v045_copy_a | source.observed | {"facts": ["Ca", "Cc"], "goal_atom": "Cc", "probe_atom": "Cc"} | {"probe_atom": "Cc", "goal_atom": "Cc", "facts": ["Ca", "Cc"]} | True |
| criterion_goal_is_fact__v045_copy_a | source.primitives | {"in_facts": true, "same_as_goal": true} | {"same_as_goal": true, "in_facts": true} | True |
| criterion_goal_is_fact__v045_copy_a | input_projection | {"a": true, "b": true} | {"a": true, "b": true} | True |
| criterion_goal_is_fact__v045_copy_a | operator.value | true | true | True |
| criterion_goal_not_fact__v045_and_not_b | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Cc"} | {"probe_atom": "Cc", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_goal_not_fact__v045_and_not_b | source.primitives | {"in_facts": false, "same_as_goal": true} | {"same_as_goal": true, "in_facts": false} | True |
| criterion_goal_not_fact__v045_and_not_b | input_projection | {"a": true, "b": false} | {"a": true, "b": false} | True |
| criterion_goal_not_fact__v045_and_not_b | operator.value | false | true | False |
| criterion_neither__v045_and_ab | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Cz"} | {"probe_atom": "Cz", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_neither__v045_and_ab | source.primitives | {"in_facts": false, "same_as_goal": false} | {"same_as_goal": false, "in_facts": false} | True |
| criterion_neither__v045_and_ab | input_projection | {"a": false, "b": false} | {"a": false, "b": false} | True |
| criterion_neither__v045_and_ab | operator.value | false | false | True |
| criterion_fact_not_goal__v045_not_b | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Ca"} | {"probe_atom": "Ca", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_fact_not_goal__v045_not_b | source.primitives | {"in_facts": true, "same_as_goal": false} | {"same_as_goal": false, "in_facts": true} | True |
| criterion_fact_not_goal__v045_not_b | input_projection | {"a": false, "b": true} | {"a": false, "b": true} | True |
| criterion_fact_not_goal__v045_not_b | operator.value | false | false | True |
| criterion_goal_not_fact__v045_and_ab | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Cc"} | {"probe_atom": "Cc", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_goal_not_fact__v045_and_ab | source.primitives | {"in_facts": false, "same_as_goal": true} | {"same_as_goal": true, "in_facts": false} | True |
| criterion_goal_not_fact__v045_and_ab | input_projection | {"a": true, "b": false} | {"a": true, "b": false} | True |
| criterion_goal_not_fact__v045_and_ab | operator.value | false | false | True |
| criterion_goal_is_fact__v045_not_b | source.observed | {"facts": ["Ca", "Cc"], "goal_atom": "Cc", "probe_atom": "Cc"} | {"probe_atom": "Cc", "goal_atom": "Cc", "facts": ["Ca", "Cc"]} | True |
| criterion_goal_is_fact__v045_not_b | source.primitives | {"in_facts": true, "same_as_goal": true} | {"same_as_goal": true, "in_facts": true} | True |
| criterion_goal_is_fact__v045_not_b | input_projection | {"a": true, "b": true} | {"a": true, "b": true} | True |
| criterion_goal_is_fact__v045_not_b | operator.value | false | false | True |
| criterion_goal_not_fact__v045_copy_a | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Cc"} | {"probe_atom": "Cc", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_goal_not_fact__v045_copy_a | source.primitives | {"in_facts": false, "same_as_goal": true} | {"same_as_goal": true, "in_facts": false} | True |
| criterion_goal_not_fact__v045_copy_a | input_projection | {"a": true, "b": false} | {"a": true, "b": false} | True |
| criterion_goal_not_fact__v045_copy_a | operator.value | true | true | True |
| criterion_neither__v045_copy_a | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Cz"} | {"probe_atom": "Cz", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_neither__v045_copy_a | source.primitives | {"in_facts": false, "same_as_goal": false} | {"same_as_goal": false, "in_facts": false} | True |
| criterion_neither__v045_copy_a | input_projection | {"a": false, "b": false} | {"a": false, "b": false} | True |
| criterion_neither__v045_copy_a | operator.value | false | false | True |
| criterion_goal_is_fact__v045_and_not_b | source.observed | {"facts": ["Ca", "Cc"], "goal_atom": "Cc", "probe_atom": "Cc"} | {"probe_atom": "Cc", "goal_atom": "Cc", "facts": ["Ca", "Cc"]} | True |
| criterion_goal_is_fact__v045_and_not_b | source.primitives | {"in_facts": true, "same_as_goal": true} | {"same_as_goal": true, "in_facts": true} | True |
| criterion_goal_is_fact__v045_and_not_b | input_projection | {"a": true, "b": true} | {"a": true, "b": true} | True |
| criterion_goal_is_fact__v045_and_not_b | operator.value | false | false | True |
| criterion_fact_not_goal__v045_copy_a | source.observed | {"facts": ["Ca"], "goal_atom": "Cc", "probe_atom": "Ca"} | {"probe_atom": "Ca", "goal_atom": "Cc", "facts": ["Ca"]} | True |
| criterion_fact_not_goal__v045_copy_a | source.primitives | {"in_facts": true, "same_as_goal": false} | {"same_as_goal": false, "in_facts": true} | True |
| criterion_fact_not_goal__v045_copy_a | input_projection | {"a": false, "b": true} | {"a": false, "b": true} | True |
| criterion_fact_not_goal__v045_copy_a | operator.value | false | false | True |
| criterion_goal_is_fact__v045_and_ab | source.observed | {"facts": ["Ca", "Cc"], "goal_atom": "Cc", "probe_atom": "Cc"} | {"probe_atom": "Cc", "goal_atom": "Cc", "facts": ["Ca", "Cc"]} | True |
| criterion_goal_is_fact__v045_and_ab | source.primitives | {"in_facts": true, "same_as_goal": true} | {"same_as_goal": true, "in_facts": true} | True |
| criterion_goal_is_fact__v045_and_ab | input_projection | {"a": true, "b": true} | {"a": true, "b": true} | True |
| criterion_goal_is_fact__v045_and_ab | operator.value | true | true | True |

## 구성요소별 결과

| 과제 | 성공 | 기록 | 배정 |
| --- | ---: | ---: | ---: |
| operator_atom | 15 | 16 | 16 |

기준 판정 정답 패턴과 실제 응답 패턴은 `component_diagnostics.json`에서 분리한다.
동일한 고정 증명의 전체 도식/최종 도식 단독 결과도 짝지어 보존한다. 이는 진단 비교이지 본 실험의 성공 기준 완화가 아니다.

## 실행 모드

체크포인트: instruct-2507; 모드: non-thinking; think 필드: omitted.
메타데이터 검사와 실제 응답 채널 검사를 분리했다. 이 표는 모델 성능이 개선됐다는 뜻이 아니다.
예산: {"temperature": 0.7, "top_p": 0.8, "top_k": 20, "min_p": 0.0, "repeat_penalty": 1.0, "num_ctx": 8192, "num_predict": 4096, "num_thread": 6, "num_batch": 256}

## 실패 구분

분리 과제는 위 실제값/기대값과 task_comparisons.json을 기준으로 본다. 통합 증명 전체가 없는 과제의 층위 집계를 0건 성공/실패로 해석하지 않는다.

```json
{
  "applicable": false,
  "note": "통합 증명용 오류 집계를 분리 과제에 0건으로 적용하지 않는다. task_comparisons와 details를 확인한다."
}
```

## 비용

```json
{
  "known_prompt_eval_count_sum": 2388,
  "unknown_prompt_eval_count_cases": 0,
  "known_prompt_eval_cached_count_sum": 1989,
  "unknown_prompt_eval_cached_count_cases": 0,
  "known_eval_count_sum": 96,
  "unknown_eval_count_cases": 0,
  "known_api_wall_seconds_sum": 7.64368000000286,
  "note": "실패 호출도 포함. 미수신 비용은 null/unknown이며 0으로 추정하지 않음. 비용 절감 결론이 아님.",
  "token_scope": "eval_count는 API 생성 토큰 합계. thinking/최종 토큰을 분리해 추정하지 않는다."
}
```

## 해석 범위

분리 진단 16회 수행 여부. 고정 입력에 대한 구성요소 작업이며 통합 A/D/M 결과에 합산하지 않음.

반복 시드는 같은 문제의 반복 측정이다. 독립된 문제 수나 새 표본으로 부풀리지 않는다. 토큰 수·시간은 서로 다른 출력 작업량과 캐시·최초 로딩을 포함하므로 곧바로 효율 향상으로 읽지 않는다.

## 형식·내용 진단

`task_evidence.json`은 채점과 별도인 읽기 전용 증거다. 오류 응답도 정규화하거나 보충하지 않는다.
같은 도식 범위의 여러 조건은 모두 보존한다. 임의로 마지막 조건을 대표 결과로 쓰지 않는다.

## 단일 연산별 진단

| 연산 | 성공/배정 | 양성 검출/양성 입력 | 거짓 양성 | 평가 불가 |
| --- | ---: | ---: | ---: | ---: |
| copy_a | 4/4 | 2/2 | 0 | 0 |
| and_ab | 4/4 | 1/1 | 0 | 0 |
| not_b | 4/4 | 2/2 | 0 | 0 |
| and_not_b | 3/4 | 0/1 | 0 | 0 |

세 모델 반환값을 그대로 조립한 조건부 성공: 3/4.
NOT 단독 결과로 다른 답을 자동 보충하지 않는다. 과거 중간값 재사용이므로 신규 종단 간 ADM 성공이 아니다.
단일 연산이 모두 맞으면 원래 다중 출력 과제와 분리해서 해석한다. 실패가 남으면 같은 진단의 다른 모델/환경 대조가 필요하며, 모델 크기를 단독 원인으로 단정하지 않는다.
